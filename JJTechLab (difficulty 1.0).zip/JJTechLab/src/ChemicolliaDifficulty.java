import java.awt.*;
import java.awt.event.*;
import java.util.Random;
import javax.swing.*;

// checklist: if loops, while loop?, figure out how to incorporate the timer, counter, random
// userterm = chemterm

public class ChemicolliaDifficulty extends Words {
	static String userTerm = "";
	static String bossTerm = "";

	static int counter = 0;
	static int qNum = 0;

	static JLabel label;
	static JButton Enter;
	static JTextArea textarea;
	static JTextField textfield;
	static JPanel panel;
	//random

	//Random random = new Random(); //setting up random numbers
	//answer = random.nextInt(6) + 1;
	// if randomnum = [x] bossterm = [x]

	public static JFrame variables() {
		Random random = new Random(); //setting up random numbers
		qNum = random.nextInt(5) + 1;
		textfield = new JTextField(16);
		textarea = new JTextArea(5, 20);
		label = new JLabel("SPELLING TEST"); // text prompting user for input
		Enter = new JButton("Enter"); // buttons for user to guess with

		textarea.setCaretPosition(textarea.getDocument().getLength());
		textarea.setEditable(false);

		panel = new JPanel(); // creates new panel for the interface
		panel.setBorder(BorderFactory.createEmptyBorder(30, 30, 10, 30)); //panel dimensions
		panel.add(label);
		panel.add(textfield);
		panel.add(textarea);
		panel.add(Enter); // adding number and quit/new game/score buttons to panel

		JFrame frame = new JFrame(); // creates new frame for the panel
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);// exits program upon closing the window
		frame.setSize(300, 300); //setting frame dimensions
		frame.getContentPane().add(panel); //adding panel to frame
		return frame;
	}


	public static void main(String[] args) { 
		JFrame frame = variables(); //importing variables to JFrame and making JFrame visible
		frame.setVisible(true);
		new ChemicolliaDifficulty();



		Enter.addActionListener(new ActionListener() { //if enter is pressed
			public void actionPerformed(ActionEvent e) {
				userTerm = textfield.getText().replaceAll("[^a-zA-Z0-9]", "").trim().toLowerCase();
				terms();
				//textarea.append("you said " + userTerm); //change this to if userTerm = bossTerm

				for (counter = 0; counter < 3; counter++) {
					if (counter == 1) {
						bossTerm = easy[qNum];
						label.setText(bossTerm);
						if (userTerm.equals(bossTerm)) {
							textarea.setText("");
							textarea.append("You're right! You have " + counter + " point!");
							counter++;
						} 
						else if (!userTerm.equals(bossTerm)){
							textarea.setText("");
							textarea.append("Wrong.");
						}
					}
					else if (counter == 2) { //how to make the level progress, if i remove the else's it progresses but incorrectly
						Random random = new Random(); //setting up random numbers
						qNum = random.nextInt(5) + 1;
						bossTerm = medium[qNum];
						label.setText(bossTerm);
						if (userTerm.equals(bossTerm)) {
							textarea.setText("");
							textarea.append("You're right! You have " + counter + " points!");
							counter++;
						} 
						else if (!userTerm.equals(bossTerm)){
							textarea.setText("");
							textarea.append("Wrong.");
						}
					}
					else if (counter == 3) {
						Random random = new Random(); //setting up random numbers
						qNum = random.nextInt(5) + 1;
						bossTerm = hard[qNum];
						label.setText(bossTerm);
						if (userTerm.equals(bossTerm)) {
							textarea.setText("");
							textarea.append("You're right! You have " + counter + " points!");
							counter++;
						}
						else if (!userTerm.equals(bossTerm)){
							textarea.setText("");
							textarea.append("Wrong.");
						}
					}
				}
			}
		});

		terms(); //need linked list, need to figure out 

		if (counter == 0) {
			bossTerm = easy[qNum];
			label.setText(bossTerm);
		} if (userTerm.equals(bossTerm)) {
			textarea.setText("");
			counter++;
			textarea.append("You're right! You have " + counter + " point!");
		} if (counter == 2) {
			bossTerm = hard[qNum];
			label.setText(bossTerm);
		}
	}
}