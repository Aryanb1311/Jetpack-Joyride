import java.awt.*;
import java.awt.event.*;
import java.util.Random;
import javax.swing.*;

/*checklist: make the lasers rotate (not done)
 * make them bounce off the wall (DONE)
 * SIZE IS SUBJECT TO CHANGE i just needed a visual
 */

public class TechLabObstacles extends JFrame {
	
	obstacles discoLaser;
	Graphics graphics;
	Image image;

	private static int FW = 400;
	private static int FH = 400;
	int x = 260;
	int y = 160;
	int speedx = 5;
	int speedy = 5;

	laserPanel laserPanel = new laserPanel();

	public TechLabObstacles() {
		Random random = new Random();
		ActionListener laserMovement = new AbstractAction() {
			public void actionPerformed(ActionEvent e) {
				if (y > (FH-10) || y <= 0) {
					//speedy = random.nextInt(200) + 1; //this doesn't work but it's so funny
					speedy = -speedy;
				}
				x = x - speedx;
				y = y - speedy;
				laserPanel.repaint();
				discoLaser.setLocation(x, y);
			}
		};
		Timer laserSpeed = new Timer(50, laserMovement);
		laserSpeed.start();
		add(laserPanel);
		discoLaser = new obstacles (discoLaserX, discoLaserY, discoLaserWidth, discoLaserHeight, Color.(255, 149, 42);

		pack();
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
	}

	private class laserPanel extends JPanel {

		protected void paintComponent(Graphics g) {
			Graphics2D g2d = (Graphics2D) g;
			/*super.paintComponent(g); //so the shape doesn't leave afterimages
			//Color red = Color.decode("#FF0000");
			g2d.setColor(new Color(117, 121, 135)); //remove new color, add 'red'
			g.fillOval(350, 115, 100, 100); 
			g2d.setColor(new Color(255, 149, 42));
			g.fillRect(x, y, 70, 10);*/
			image = createImage(this.getWidth(), this.getHeight());
			graphics = image.getGraphics();
			g.drawImage(image, 0, 0, this);
			
			discoLaser.draw(g);
		}

		public Dimension getPreferredSize() {
			return new Dimension(FW, FH);
		}
	}

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				new TechLabObstacles();
			}
		});
	}
}