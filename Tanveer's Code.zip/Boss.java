public class Boss 
{
	public String name; //create the variable for the name of the boss 
	public int progressBar; //create the variable for the progress bar

	//overloading 
	public Boss() //when user enters no parameters do this
	{
		//set the values to 0/null
		name = "";
		progressBar = 0; 
	}
	
	//overloading 
	public Boss(String startName, int startProgressBar) //when user enters 3 parameters do this method 
	{
		//store the parameter values into the attributes variables 
		name = startName;
		progressBar = startProgressBar;
	}

	//set the value for name
	public void setName (String newValue)
	{
		name = newValue; //set value of the parameter into the name variable
	}
	
	//set the value for progress bar
	public void setProgressBar (int newValue) 
	{ 
		progressBar = newValue; //set value of the parameter into the progressBar variable
	}

	//get the value in the name variable
	public String getName ( ) 
	{
		return name; //return the name variable 
	}

	//get the value in the progressBar variable 
	public int getProgressBar ( ) 
	{
		return progressBar; //return the progressBar variable 
	}
	

}
