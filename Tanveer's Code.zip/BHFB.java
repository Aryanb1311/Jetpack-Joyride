
public class BHFB extends Boss
{
	public int anchorTime; //create the variable for the accuracyOfMissiles of the boss 

	//overloading 
	public BHFB() //when user enters no parameters do this
	{
		//set the values to 0/null
		name = "";
		progressBar = 0;
		anchorTime = 0;
	}
	
	//overloading 
	public BHFB(String startName, int startProgressBar, int startAnchorTime) //when user enters 3 parameters do this method 
	{
		//store the parameter values into the attributes variables 
		name = startName;
		progressBar = startProgressBar;
		anchorTime = startAnchorTime;
	}
	
	
	//set the value for anchorTime
	public void setAnchorTime (int newValue) 
	{ 
		anchorTime = newValue; //set value of the parameter into the anchorTime variable
	}


	//get the value in the anchorTime variable 
	public int getAnchorTime ( ) 
	{
		return anchorTime; //return the anchortime variable 
	}

}
