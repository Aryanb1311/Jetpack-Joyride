
public class Chemicollia extends Boss
{
	public String chemTerm; //create the variable for the accuracyOfMissiles of the boss 

	//overloading 
	public Chemicollia() //when user enters no parameters do this
	{
		//set the values to 0/null
		name = "";
		progressBar = 0;
		chemTerm = "";
	}
	
	//overloading 
	public Chemicollia(String startName, int startProgressBar, String startChemTerm) //when user enters 3 parameters do this method 
	{
		//store the parameter values into the attributes variables 
		name = startName;
		progressBar = startProgressBar;
		chemTerm = startChemTerm;
	}
	
	
	//set the value for ChemTerm
	public void setChemTerm (String newValue) 
	{ 
		chemTerm = newValue; //set value of the parameter into the ChemTerm variable
	}


	//get the value in the chemTerm variable 
	public String getChemTerm ( ) 
	{
		return chemTerm; //return the chemTerm variable 
	}

}
