//import libraries 
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.lang.Math;
import java.util.concurrent.TimeUnit;

public class ScienceLabObstacles extends JPanel implements ActionListener, KeyListener
{
	obstacles acidTurret;
	obstacles explodingBeaker;
	obstacles scientist;
	obstacles bullet;
	
	obstacles BHFB;
	obstacles anchor;
	
	obstacles fishermanPortal;
	
	
	public int fishermanWidth = 40, fishermanHeight = 75;
	public int anchorWidth = 25, anchorHeight = 30;
	
	public int fishermanX = Main.getFrameWidth() - fishermanWidth - 25, fishermanY =  Main.getFrameHeight() - fishermanHeight - 35; //instantiate x and y coordinates of the fisherman
	public int anchorX = fishermanX - anchorWidth, anchorY = fishermanY - anchorHeight; //instantiate and set x and y coordinates for the anchor
	
	public int scientistX, scientistY;
	public int bulletX, bulletY;
	public int scientistWidth = 30, scientistHeight = 60;
	public int bulletWidth = 25, bulletHeight = 7;
	
	public boolean scientistC = false, bulletC = false, explodingBeakerC = false, acidTurretC = false, fishermanC = false;
	public boolean caught = false;
	
	public int explodingBeakerWidth = 50, explodingBeakerHeight = 30; //height and width of exploding explodingBeaker obstacle 
	public int acidTurretWidth = 60, acidTurretHeight = 20; //height and width of the acidTurret turret obstacle 
	
	public int acidTurretX, acidTurretY; //instantiate x and y coordinates of the acidTurret turret 
	public int explodingBeakerX, explodingBeakerY; //instantiate and set x and y coordinates for the explodding explodingBeaker
	
	//timers
	public Timer explodingBeakerT, expansion; //timers for the exploding explodingBeaker obstacles 
	public Timer acidTurretT; //timer for the acidTurret turret obstacle 
	public Timer scientistT;
	public Timer fishermanT;
	public Timer game;
	
	
	public int s1, s2;
	
	
	public int up = -3;
	public int down = 3;
	
	Timer t = new Timer(10, this);
	Player p = new Player(30, Main.getFrameHeight()/2 - 30, 30, 30, 0, 0, Color.BLACK);
	public int seconds = 1;
	
	public int speedInc;
	
	double a, b, c; //constants for the quadratic formula 
	
	int anchorThrown = 3;
	
	
	public ScienceLabObstacles() 
	{
		addKeyListener(this);
        setFocusable(true);
        requestFocusInWindow();
		
		t.start();
		

	}
	public void actionPerformed(ActionEvent arg0) {
		int y = (int)p.getY();
		
		if(y<0)
		{
			p.setLocation(30, 0);
		}
		else if (y > Main.getFrameHeight()- 75)
		{
			p.setLocation(30, Main.getFrameHeight()- 75);

		}
		
		p.tick();

		repaint();
		
	}


	
	public void keyPressed(KeyEvent k) 
	{	

		switch(k.getKeyCode()) 
		{
		
		case KeyEvent.VK_SPACE:
			
			//if(p.getLocation() == 0);
			p.setDy(up);
			
			break;
		}
	
	}

	
	public void keyReleased(KeyEvent k) {
		
		switch(k.getKeyCode()) {
		case KeyEvent.VK_SPACE:
			p.setDy(down);
			break;
	
		}
		
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	
	public void startGame()
	{
		game = new Timer(1000, this); //new timer for the object moving 

		game.addActionListener(new ActionListener()  //everytime the timer ticks it goes to this action listener 
		{
			public void actionPerformed(ActionEvent e) 
			{
				seconds++;
			}
		});
		game.start();

	}
	
	public void endGame()
	{
		game.stop();
		System.out.println(seconds);
	}
	
	public void paint(Graphics g)
	{
		
		g.clearRect(0, 0, getWidth(), getHeight());
		
		//draw the obstacles 
		if (acidTurretC)
		{
			acidTurret.draw(g);
		}
		if (explodingBeakerC)
		{
			explodingBeaker.draw(g);
		}
		if (scientistC)
		{
			scientist.draw(g);
			bullet.draw(g);
		}	
		p.draw(g);
		if (fishermanC)
		{
			BHFB.draw(g);
			anchor.draw(g);
		}

	}//paint method ends
	
	
	
	public void startScientist()
	{
		scientistC = true; 
		
		scientistX = (Main.getFrameWidth() - 100);
		scientistY = (Main.getFrameHeight()/2);
		
		bulletY = (Main.getFrameHeight()/2);
		bulletX = scientistX;

		
		speedInc = 3;
		int bulletSpeed = 3;
		
		scientist = new obstacles (scientistX, scientistY, scientistWidth, scientistHeight, Color.BLUE); //graphic being instantiated 
		bullet = new obstacles (bulletX, bulletY, bulletWidth, bulletHeight, Color.GRAY); //graphic being instantiated 

		
		scientistT = new Timer(3, this); //new timer for the object moving 
		scientistT.addActionListener(new ActionListener()  //everytime the timer ticks it goes to this action listener 
        {
            public void actionPerformed(ActionEvent e) 
            {
            		if (scientistY > (Main.getFrameHeight()-scientistHeight) || scientistY <= 0) 
            		{
            			speedInc = -speedInc;
    				}
            		scientistY = scientistY - speedInc;
            		scientist.setLocation(scientistX, scientistY);
            		
            		if(bulletX >= -bulletWidth) //if in frame then only move 
                	{
                		bulletX = bulletX - bulletSpeed ; //changes the increments of the movement 
                		bullet.setLocation(bulletX, bulletY);
                	}//if ends 
            		else 
            		{
            			bulletX = scientistX;
            			bulletY = scientistY;
            		}
            		
            		checkCollision();
            		repaint();//repaints the obstacle 
            }  
        });
		scientistT.start(); //starts the timer 	
	}
	
	
	public void startExplodingBeaker(int speed, int rateOfExpansion) 
	{		
		explodingBeakerC = true;
		explodingBeakerY = Main.randomNumGenerator(0, (Main.getFrameHeight() - explodingBeakerHeight)); //get random Y in the size of the frame 
		
		explodingBeakerX = Main.getFrameWidth();
		
		explodingBeaker = new obstacles (explodingBeakerX, explodingBeakerY, explodingBeakerWidth, explodingBeakerHeight, Color.YELLOW); //graphic being instantiated 
		
		explodingBeakerT = new Timer(3, this); //new timer for the object moving 
		explodingBeakerT.addActionListener(new ActionListener()  //everytime the timer ticks it goes to this action listener 
        {
            public void actionPerformed(ActionEvent e) 
            {
            	if(explodingBeakerX >= -explodingBeakerWidth) //if in frame then only move 
            	{
            		explodingBeakerX = explodingBeakerX - speed ; //changes the increments of the movement 
            		explodingBeaker.setLocation(explodingBeakerX, explodingBeakerY);
            		
            		checkCollision();

            		
            		repaint();//repaints the obstacle 
            	}//if ends 
            }  
        });
		explodingBeakerT.start(); //starts the timer 
        
		expansion = new Timer(50, this); //new timer for the rate of expansion 
		expansion.addActionListener(new ActionListener()  //every time the timer ticks it goes to this action listener 
        {
            public void actionPerformed(ActionEvent e) 
            {
            	if(explodingBeakerX <  3*Main.getFrameWidth()/4) //only expand at 3/4 of the width of the frame
            	{
        		explodingBeakerWidth = explodingBeakerWidth + rateOfExpansion; //expand the width of the obstacle 
        		explodingBeakerHeight = explodingBeakerHeight + rateOfExpansion; //expand the height of the obstacle 
        		explodingBeaker.setSize(explodingBeakerWidth, explodingBeakerHeight);
        		
        		repaint(); //repaint the obstacle 
            	}
            }
        });
		expansion.start(); //start the timer 
	}//startExplodingBeaker method ends
	
	
	
	
	

	
	
	public void startAcidTurret()
	{
		acidTurretC = true; //lets the program know that this obstacle is runnign 

		acidTurretT = new Timer(20, this); //new timer for the object moving 
		
		int xStart = 800; //starting point of the obstacles
		
		//random values for where the acid will shoot 
		//(made these values to make sure that it will always hit the player)
	    int yStart = Main.randomNumGenerator(100, 500); //starting point of the obstacles 
	    int xMax = Main.randomNumGenerator(0, 500); //max point 
	    int yMax = Main.randomNumGenerator(3, (yStart - 100)); //max point 
	    
	    acidTurretX = xStart; //set starting position 	    
		acidTurretY = yStart; //set starting position 
		
		//create the obstacle so it can be drawn
		acidTurret = new obstacles (acidTurretX, acidTurretY, 
		acidTurretWidth, acidTurretHeight, Color.GREEN);
		
		//Calculations for constants depending on the starting point and the max point  
		a = (yStart - yMax) / Math.pow((xStart - xMax), 2);
        b = -2 * a * xMax;
        c = yMax + a * Math.pow(xMax, 2);
		
        //every time the timer ticks it goes to this action listener 
		acidTurretT.addActionListener(new ActionListener()  
        {
            public void actionPerformed(ActionEvent e) 
            {
            	if(acidTurretX >= -acidTurretWidth) //if in frame then do this 
            	{
                    int x = acidTurretX; //to make the equation look cleaner 
                    
            		acidTurretX -= 10; // goes to the left -10
            		acidTurretY = (int)Math.round(a*x*x + b*x + c); // y = ax^2 + bx + c
            		
            		//set location of obstacle
            		acidTurret.setLocation(acidTurretX, acidTurretY); 
            		
            		checkCollision(); //check collision detection 
            		
            		repaint();//repaints the obstacle 
            	}//if ends 
            }  
        });
		acidTurretT.start(); //starts the timer 
	}//startAcidTurret method ends
	
	
	public void fisherman()
	{
		fishermanX = Main.getFrameWidth() - fishermanWidth - 25;
		fishermanY =  Main.getFrameHeight() - fishermanHeight - 35; //instantiate x and y coordinates of the fisherman
		
		
		int xStart = fishermanX - anchorWidth; //starting point of the obstacles
		
	    int yStart = fishermanY - anchorHeight;
	    int xMax = Main.randomNumGenerator(0, 400); //max point 
	    int yMax = Main.randomNumGenerator(3, (yStart - 100)); //max point 
	    
	    anchorX = xStart; //set starting position 	    
		anchorY = yStart; //set starting position 
		
		//Calculations for constants depending on the starting point and the max point  
		a = (yStart - yMax) / Math.pow((xStart - xMax), 2);
        b = -2 * a * xMax;
        c = yMax + a * Math.pow(xMax, 2);
	}
	
	
	
	
	public void startFisherman()
	{
		anchorThrown = 3;
		
		fishermanC = true; //lets the program know that this obstacle is runnign 

		fishermanT = new Timer(20, this); //new timer for the object moving 

		//create the boss so it can be drawn
				BHFB = new obstacles (fishermanX, fishermanY, fishermanWidth, fishermanHeight, Color.GREEN); //graphic being instantiated 
				anchor = new obstacles (anchorX, anchorY, anchorWidth, anchorHeight, Color.BLACK); //graphic being instantiated 
				BHFB.setLocation(fishermanX, fishermanY);
				anchor.setLocation(anchorX, anchorY);
			
		fisherman();
		
        //every time the timer ticks it goes to this action listener 
		fishermanT.addActionListener(new ActionListener()  
        {
            public void actionPerformed(ActionEvent e) 
            {
            	if (anchorThrown == 0)
            	{
            		fishermanT.stop();
            		anchor.setLocation(-10000, -10000);
            		fishermanC = false;
            	}
            	else if(anchorX >= -anchorWidth) //if in frame then do this 
            	{
            		if (anchorX == -10 )
            		{
            			anchorThrown--;
            		}
                    int x = anchorX; //to make the equation look cleaner 
                    
            		anchorX -= 10; // goes to the left -10
            		anchorY = (int)Math.round(a*x*x + b*x + c); // y = ax^2 + bx + c
            		
            		//set location of obstacle
            		anchor.setLocation(anchorX, anchorY); 
            		
            		//collision detection 
            		checkCollision();
            		
            		repaint();//repaints the obstacle 
            	}//if ends 
            	else
            	{
            		fisherman();
            	}


            }  
        });
		fishermanT.start(); //starts the timer
	}
	
	
	
	
	
	public void stopObstacles()
	{
		explodingBeaker.setLocation(-10000, -10000);
		explodingBeakerT.stop(); //stops the timer 
		expansion.stop(); //stop the expansion 
		//sets the obstacle to the default size 
		explodingBeakerHeight = 30; 
		explodingBeakerWidth = 30; 
		explodingBeaker.setSize(explodingBeakerWidth, explodingBeakerWidth);

		acidTurret.setLocation(-10000, -10000);
		acidTurretT.stop(); //stops the timer 
		
		bullet.setLocation(-10000, -10000);
		scientist.setLocation(-10000, -10000);
		scientistT.stop();
		

		
		
		repaint();
	} //stopExplodingBeakerObstacle method ends 

	
	
	//testing collison detection 
	public void checkCollision()
	{
		if(explodingBeakerC || acidTurretC || bulletC) {

		if(explodingBeaker.intersects(p) || acidTurret.intersects(p) || bullet.intersects(p))
		{
			s1 = 0;
			stopObstacles();
			Timer t2 = new Timer (1000, this);

			t2.addActionListener(new ActionListener()  //everytime the timer ticks it goes to this action listener 
					{
						public void actionPerformed(ActionEvent e) 
						{
							s1++;       
							if (s1 == 3)
							{
								t2.stop();
								startAcidTurret(); //1st parameter is y starting position, 2nd is x position of tipping point, and 3rd is y position of tipping point  
								startExplodingBeaker(3, 1); //first parameter is speed and second parameter is rate of expansion 
								startScientist();
								s1 = 0;
								
							}
						}
					});
					t2.start();

		}
		}
		
		if(fishermanC)
		{
		if(anchor.intersects(p))
		{
    		anchor.setLocation(-10000, -10000);

			up = -2;
			down = 9;
			fishermanT.stop();
			p.setColor(Color.RED);

			s2 = 0;
			Timer timer = new Timer (1000, this);
			timer.addActionListener(new ActionListener()  //everytime the timer ticks it goes to this action listener 
			{
				public void actionPerformed(ActionEvent e) 
				{
					s2++;       
					System.out.println(s2);
					if (s2 == 10)
					{
						up = -3;
						down = 3;
						caught = false;
						s2 = 0;
						anchorThrown = 0;
	            		BHFB.setLocation(-10000, -10000);
	        			p.setColor(Color.BLACK);

						timer.stop();

					}
				}
			});
			timer.start();

		}
		}
	}









}
