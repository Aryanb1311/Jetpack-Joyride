//import libraries 
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.Math;

public class ScienceLabObstacles extends JPanel implements ActionListener
{
	obstacles acidTurret;
	obstacles explodingBeaker;
	Graphics graphics;
	Image image;
	
	public int explodingBeakerWidth = 50, explodingBeakerHeight = 30; //height and width of exploding explodingBeaker obstacle 
	public int acidTurretWidth = 60, acidTurretHeight = 20; //height and width of the acidTurret turret obstacle 
	
	public int acidTurretX, acidTurretY; //instantiate x and y coordinates of the acidTurret turret 
	public int explodingBeakerX = Main.getFrameWidth(), explodingBeakerY; //instantiate and set x and y coordinates for the explodding explodingBeaker
	
	//timers
	public Timer explodingBeakerT, expansion; //timers for the exploding explodingBeaker obstacles 
	public Timer acidTurretT; //timer for the acidTurret turret obstacle 
	
	public int speedInc; //increment of how fast the object is moving 
	
	double a, b, c; //constants for the quadratic formula 
	
	
	
	
	
	
	
	public void paint(Graphics g)
	{
		image = createImage(this.getWidth(), this.getHeight());
		graphics = image.getGraphics();
		g.drawImage(image, 0, 0, this);
		
		acidTurret.draw(g);
		explodingBeaker.draw(g);
		
		
		
//		super.paint(g);
//		Color dg = new Color(17, 59, 8); //make a new color 
//		
//		g.setColor(dg); //set the color of the obstacle 
//		g.fillRect(explodingBeakerX, explodingBeakerY, explodingBeakerWidth, explodingBeakerHeight); //set x, y, width, and height of the rectangle graphic (exploding explodingBeaker)
//	
//		g.setColor(Color.GREEN); //set the color of the obstacle
//		g.fillRect(acidTurretX, acidTurretY, acidTurretWidth, acidTurretHeight); //set x, y, width, and height of the rectangle graphic (acidTurret of turret)
	}//paint method ends
	
	
	public void startExplodingBeaker(int speed, int rateOfExpansion)
	{
		speedInc = speed; //sets the speed Inc that the user selected 
		
		explodingBeakerY = Main.randomNumGenerator((Main.getFrameHeight()/Main.getFrameHeight()), (Main.getFrameHeight() - explodingBeakerHeight)); //get random Y in the size of the frame 
		
		explodingBeaker = new obstacles (explodingBeakerX, explodingBeakerY, explodingBeakerWidth, explodingBeakerHeight, Color.YELLOW);
		
		explodingBeakerT = new Timer(5, this); //new timer for the object moving 
		explodingBeakerT.addActionListener(new ActionListener()  //everytime the timer ticks it goes to this action listener 
        {
            public void actionPerformed(ActionEvent e) 
            {
            	if(explodingBeakerX >= -explodingBeakerWidth) //if in frame then only move 
            	{
            		explodingBeakerX = explodingBeakerX - speedInc ; //changes the increments of the movement 
            		explodingBeaker.setLocation(explodingBeakerX, explodingBeakerY);
            		
            		checkCollision();

            		
            		repaint();//repaints the obstacle 
            	}//if ends 
            }  
        });
		explodingBeakerT.start(); //starts the timer 
        
		expansion = new Timer(50, this); //new timer for the rate of expansion 
		expansion.addActionListener(new ActionListener()  //every time the timer ticks it goes to this action listener 
        {
            public void actionPerformed(ActionEvent e) 
            {
            	if(explodingBeakerX <  3*Main.getFrameWidth()/4) //only expand at 3/4 of the width of the frame
            	{
        		explodingBeakerWidth = explodingBeakerWidth + rateOfExpansion; //expand the width of the obstacle 
        		explodingBeakerHeight = explodingBeakerHeight + rateOfExpansion; //expand the height of the obstacle 
        		explodingBeaker.setSize(explodingBeakerWidth, explodingBeakerHeight);
        		
        		repaint(); //repaint the obstacle 
            	}
            }
        });
		expansion.start(); //start the timer 
	}//startExplodingBeaker method ends
	
	
	public void stopExplodingBeakerObstacle()
	{
		explodingBeakerT.stop(); //stops the timer 
		expansion.stop(); //stop the expansion 
		//sets the obstacle to the default size 
		explodingBeakerHeight = 30; 
		explodingBeakerWidth = 30; 
		explodingBeaker.setSize(explodingBeakerWidth, explodingBeakerWidth);
		repaint();
	} //stopExplodingBeakerObstacle method ends 
	
	
	public void stopAcidTurretObstacle()
	{
		acidTurretT.stop(); //stops the timer 
		repaint(); //repaint the obstacle
	} //stopAcidTurretObstacle method ends 
	
	
	public void startAcidTurret(int y_start, int x_max, int y_max)
	{
		acidTurretT = new Timer(20, this); //new timer for the object moving 
		
		int xStart = 800; //starting point of the obstacles
	    int yStart = y_start; //starting point of the obstacles 
	    int xMax = x_max; //max point 
	    int yMax = y_max; //max point 
	    acidTurretX = xStart; //set starting position 	    
		acidTurretY = yStart; //set starting position 
		
		acidTurret = new obstacles (acidTurretX, acidTurretY, acidTurretWidth, acidTurretHeight, Color.GREEN);
		
		//Calculations for constants  
		a = (yStart - yMax) / Math.pow((xStart - xMax), 2);
        b = -2 * a * xMax;
        c = yMax + a * Math.pow(xMax, 2);
		
		acidTurretT.addActionListener(new ActionListener()  //everytime the timer ticks it goes to this action listener 
        {
            public void actionPerformed(ActionEvent e) 
            {
            	if(acidTurretX >= -acidTurretWidth) //if in frame then do this 
            	{
                    int x = acidTurretX; //to make the equation look cleaner 
                    
            		acidTurretX -= 10; // goes to the left -10
            		acidTurretY = (int)Math.round(a*x*x + b*x + c); // y = ax^2 + bx + c
            		
            		acidTurret.setLocation(acidTurretX, acidTurretY);
            		
            		checkCollision();
            		
            		repaint();//repaints the obstacle 
            	}//if ends 
            }  
        });
		acidTurretT.start(); //starts the timer 
	}//startAcidTurret method ends
	
	
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		// TODO Auto-generated method stub
		
	}

	//testing collison detection 
	public void checkCollision()
	{
		if(acidTurret.intersects(explodingBeaker))
		{
			System.out.println("collision between obstacles detected");
		}
	}

	
}
