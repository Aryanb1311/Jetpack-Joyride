import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class Testing extends JPanel implements Runnable {

	public boolean gameState = false;
	public Thread thread;
	
	/**
	 * Create the panel.
	 */
	public Testing() 
	{

	}
	
	
	public synchronized void start()
	{
		if (gameState == true)
		{
			return;
		}
		gameState = true;
		thread = new Thread(this);
		thread.start();
		
	}
	
	public synchronized void stop()
	{
		if (gameState == false)
		{
			return;
		}
		gameState = false;
		try 
		{
			thread.join();
		}
		catch (InterruptedException e)
		{
			e.printStackTrace();
		}
	}
	
	
	
	public static void main(String[] args)
	{
		JFrame frame = new JFrame();
		Testing obstacles = new Testing ();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //closes frame when the x button is pressed 
		frame.setBounds(100, 100, 338, 340); //sets frame size 
		frame.setResizable(false); //makes it so that the user cannot change the size of the frame 
		frame.setLocationRelativeTo(null); //make the frame show up in the middle of the screen
		frame.setVisible(true); //sets the frame visible 
		
		obstacles.start();
	}

	public void run() 
	{
		int fps = 0;
		double timer = System.currentTimeMillis();
		long lastTime = System.nanoTime();
		double ns = 16666666.66666667;
		double delta = 0;
		while (gameState == true)
		{
			long current = System.nanoTime();
			delta += (current - lastTime) / ns;
			lastTime = current;
			while (delta >= 1)
			{
				update();
				render();
				fps++;
				delta--;	
			}
			if (System.currentTimeMillis() - timer >- 1000)
			{
				System.out.println ("FPS: " + fps);
				fps = 0;
				timer += 1000;
			}
			
		}
		stop();
	}
	
	private void update()
	{
	}
	
	private void render()
	{
		
	}

}
