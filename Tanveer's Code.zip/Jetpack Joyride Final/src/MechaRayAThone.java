
public class MechaRayAThone extends Boss
{
	public int accuracyOfMissiles; //create the variable for the accuracyOfMissiles of the boss 

	//overloading 
	public MechaRayAThone() //when user enters no parameters do this
	{
		//set the values to 0/null
		name = "";
		progressBar = 0;
		accuracyOfMissiles = 0;
	}
	
	//overloading 
	public MechaRayAThone(String startName, int startProgressBar, int startAccuracyOfMissiles) //when user enters 3 parameters do this method 
	{
		//store the parameter values into the attributes variables 
		name = startName;
		progressBar = startProgressBar;
		accuracyOfMissiles = startAccuracyOfMissiles;
	}
	
	
	//set the value for accuracyOfMissiles
	public void setAccuracyOfMissiles (int newValue) 
	{ 
		accuracyOfMissiles = newValue; //set value of the parameter into the accuracyOfMissiles variable
	}


	//get the value in the accuracyOfMissiles variable 
	public int getAccuracyOfMissiles ( ) 
	{
		return accuracyOfMissiles; //return the accuracyOfMissiles variable 
	}

}
