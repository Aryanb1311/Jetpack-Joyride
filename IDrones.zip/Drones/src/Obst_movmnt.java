
import java.awt.GridLayout;

import javax.swing.JFrame;

public class Obst_movmnt extends JFrame{
	
	public Obst_movmnt() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Obstacle");
		setSize(400, 400);
		setResizable(false);
	
		init();
	}
	
	public void init() {
		setLocationRelativeTo(null);
		
		setLayout(new GridLayout(1, 1, 0, 0));
		
		Drone s = new Drone();
		
		add(s);
		
		setVisible(true);
		
	}

	public static void main(String[] args) {
		Obst_movmnt f = new Obst_movmnt();

	}

}

