// version 1.0
// *** do getHighscore() and set highscore() later
import java.util.Timer;
import java.util.TimerTask;

class Stopwatch1 {
	private final long nanoSecondsPerSecond = 1000000000;

	private long watchStart = 0;
	private long watchStop = 0;
	private boolean stopWatchRunning = false;


	public void start () {
		this.watchStart = System.nanoTime();
		this.stopWatchRunning = true;
	}


	public void stop () {
		this.watchStop = System.nanoTime();
		this.stopWatchRunning = false;
	}

	// figuring out how to modify this chunk to use for scenery
	/*public long getElapsedSeconds() {
        long elapsedTime;

        if (stopWatchRunning)
            elapsedTime = (System.nanoTime() - watchStart);
        else
            elapsedTime = (watchStop - watchStart);

        return elapsedTime / nanoSecondsPerSecond;
    }*/

}


public class HighScore {
	
	static int lives = 0; // starts with 1
	static int bosses = 1; // add counter to count # of enemies defeated, it starts with 1 bc if it starts with 0 multiplier will not work??
	static int powerUps = 1; // add counter, doesn't start with 0 bc if it did multiplier wont work.

	// bonuses for bosses??
	static double bonus = 1.15;
	static double bonus2 = 1.25;
	static double bonusMax = 1.5;
	
	//bonuses for power ups (work on later)
	
	
	public static void main(String[] args) {

		Stopwatch1 highScore = new Stopwatch1();
		highScore.start();
		highScore.stop();

		Timer timer = new Timer();
		
        timer.scheduleAtFixedRate(new TimerTask() {
			int timePassed = 0;

			
		void finish() {
			
			double score = timePassed * bosses * powerUps;
			
			if (bosses == 2) {
				score = timePassed * bosses * powerUps * bonus;
			} else if (bosses == 3) {
				score = timePassed * bosses * powerUps * bonus2;
			} else if (bosses >= 4){
				score = timePassed * bosses * powerUps * bonusMax;
			} 
			
			System.out.println("Final score: " + score);
				
			};
			
			public void run() {
				System.out.print("Score: " + timePassed + System.lineSeparator());
				timePassed++;
				
				if (lives == 0) {
					timer.cancel(); // stops timer which allows you to 
					//System.out.println("total score: " + timePassed);  // checking to see if the score displays, it works loll
				
				finish(); // commence multiplier
				
				}
				}

		}, 0, 500);

		//System.out.println("Elapsed time in seconds: " + highScore.getElapsedSeconds())

    }
}