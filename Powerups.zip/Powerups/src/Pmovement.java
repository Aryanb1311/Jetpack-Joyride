import java.awt.GridLayout;

import javax.swing.JFrame;

public class Pmovement extends JFrame {
	
	public Pmovement() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Powerup");
		setSize(400, 400);
		setResizable(false);
	
		init();
	}
	
	public void init() {
		setLocationRelativeTo(null);
		
		setLayout(new GridLayout(1, 1, 0, 0));
		
		Powerup s = new Powerup();
		
		add(s);
		
		setVisible(true);
		
	}

	public static void main(String[] args) {
		Pmovement f = new Pmovement();

	}

}
