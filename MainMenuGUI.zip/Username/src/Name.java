
public class Name {
	
		public String name;
		
		// Fighter first constructor
		
		public void setName(String defName) // set Name 
		{
			name = defName;
		}
		
		public String getName() // get Name
		{
			return name;
		}
		
		public void getUserName() // get Fighter
		{
			System.out.println("My username is " + name + "" + "." ); // fighter statement
		}
		
	
}
