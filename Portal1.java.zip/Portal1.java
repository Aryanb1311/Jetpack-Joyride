import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;


// not finished, requires a boss battle to add, and to connect to main file
public class Portal1 extends JFrame {
	
	JLabel info = new JLabel ("Fall into the portal to fight boss & gain +1 Life");
	int placementX = 30;
	int placementY = 300;
	int w = 10;
	int r = 0;
	boolean appear = false;
	int nextPortal = 0; // if the user doesnt enter the portal
	int boss = 0;
	boolean testfornow = true;
	static JFrame PFrame = new JFrame();
	
	//timer for portal 
	int secondsPassed = 0;
	Timer portalAppear = new Timer();
	
public static void main(String[] args) {
		
		//timer for portal
		Portal1 timerPortal = new Portal1();
		timerPortal.start();
		
		
		timerPortal.setVisible(true);
		PFrame.setVisible(true);
		
		
	}
	TimerTask portalTask = new TimerTask() {
		public void run() {
			secondsPassed++;
			System.out.println("Timer: " + secondsPassed);
			
			
		
// plain warehouse		
			if (secondsPassed == 2 && nextPortal == 0) { // 5 seconds to enter portal
				appear = true;
				//if collision detection is true, reset time to zero
				if (testfornow == true) { // replace with collision detection
					PFrame.setVisible(false);
				}
				System.out.println("10 sec, boolean is " + appear);
				//ChemicolliaDifficulty2 frame = new ChemicolliaDifficulty2 ();
				ChemicolliaDifficulty2 c = new ChemicolliaDifficulty2();
				c.main(null);
				System.out.println("boss variable: " + boss);

			} 
			if (secondsPassed == 14 && nextPortal == 0) {
				secondsPassed = 0;
				nextPortal++; // they can enter the next portal in other warehouse
				appear = false;
				System.out.println("test1: " + appear + nextPortal);
				ChemicolliaDifficulty2 c = new ChemicolliaDifficulty2();
				//true to access through the boss beat, if boss beat == true, close the other frame
			} 
// science warehouse
			
			if (nextPortal == 1) {
			if (secondsPassed == 15) { // 5 seconds to enter portal
				appear = true;
				System.out.println("15 sec. boolean is " + appear);
				// need tanveer's portal
			} 
			if (secondsPassed == 19) {
				nextPortal++; // they can enter the next portal in other warehouse
				appear = false;
				System.out.println("test2: " + appear);
				secondsPassed = 0;
			}} else if (nextPortal <= 2) {
//Bio Lab
			if (secondsPassed == 20) { //5 seconds to enter portal
				appear = true;
				System.out.println("20 sec or more, boolean is " + appear);
			} 
			if (secondsPassed == 25) {
				//portals r random from now on
				Random random = new Random(); //setting up random numbers
				r = random.nextInt(2);
				appear = false;
				secondsPassed = 0;
				System.out.println("test3: " + appear);
			}}
		}
	};
	
	
	
	//when you do .start(), the timer commences
	public void start() {
		portalAppear.scheduleAtFixedRate(portalTask,0,1000);
		
	}
	
	
	class panel extends JPanel {
// this is the graphics for the portal, it being blue
		int x = 30;
		int y = 300;
		protected void paintComponent(Graphics g) { // square will be replaced with image sprites // maybe do a swap();
			Graphics2D g2 = (Graphics2D) g;
			super.paintComponent(g);

			g.setColor(Color.BLUE);
			g.fillOval(x, y, 70, 90);
		}
		}

}
