import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/*checklist: make the lasers rotate
 * make them bounce off the wall
 * SIZE IS SUBJECT TO CHANGE i just needed a visual
*/

public class TechLabObstacles extends JFrame {

	private static int FW = 400;
	private static int FH = 400;
	int x = 260;
	int y = 160;

	laserPanel laserPanel = new laserPanel();

	public TechLabObstacles() {
		ActionListener laserMovement = new AbstractAction() {
			public void actionPerformed(ActionEvent e) {
				if (x <= 0) {
					x = 260; //wont work bc of the += 10
					laserPanel.repaint();
				} else {
					x -= 10; //do y to make it go diagonally
					laserPanel.repaint();
				}
			}
		};
		Timer laserSpeed = new Timer(50, laserMovement);
		laserSpeed.start();
		add(laserPanel);

		pack();
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
	}

	private class laserPanel extends JPanel {

		protected void paintComponent(Graphics g) {
			Graphics2D g2d = (Graphics2D) g;
			super.paintComponent(g); //so the shape doesn't leave afterimages
			//Color red = Color.decode("#FF0000");
			g2d.setColor(new Color(117, 121, 135)); //remove new color, add 'red'
			g.fillOval(350, 115, 100, 100); 
			g2d.setColor(new Color(255, 149, 42));
			g.fillRect(x, y, 70, 10);
		}

		public Dimension getPreferredSize() {
			return new Dimension(FW, FH);
		}
	}

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				new TechLabObstacles();
			}
		});
	}
}