import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;
import java.util.Random;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class ChemicolliaDifficulty extends Words{


	static JLabel label;
	static JButton Enter;
	static JLabel jlabel;
	static JTextField textfield;
	static JPanel panel;
	static int qNum;
	static String userInput;

	String term;


	public static JFrame variables() {
		Random random = new Random(); //setting up random numbers
		qNum = random.nextInt(5);
		textfield = new JTextField(16);
		jlabel = new JLabel("hi");
		label = new JLabel(""); // text prompting user for input
		Enter = new JButton("Enter"); // buttons for user to guess with


		panel = new JPanel(); // creates new panel for the interface
		panel.setBorder(BorderFactory.createEmptyBorder(30, 30, 10, 30)); //panel dimensions
		panel.add(label);
		panel.add(textfield);
		panel.add(jlabel);
		panel.add(Enter); // adding number and quit/new game/score buttons to panel

		JFrame frame = new JFrame(); // creates new frame for the panel
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);// exits program upon closing the window
		frame.setSize(300, 300); //setting frame dimensions
		frame.getContentPane().add(panel); //adding panel to frame
		frame.setVisible(true);
		label.setText(easy[qNum]);


		Enter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String userInput = textfield.getText();

			}
		});


		return frame;

	}



	/// for the enter button


	public ChemicolliaDifficulty() {

		// for loop to get each character from the user input
		for (int i = 0; i < term.length(); i++) {
			userInput = textfield.getText().replaceAll("[^a-zA-Z0-9]", "").trim().toLowerCase();

			Random random = new Random(); 
			qNum = random.nextInt(5);

			terms();
			// create a linked list using the LinkedList class
			LinkedList<String> Words = new LinkedList<>();

			// Add elements to LinkedList
			//  Words.add("Dog");
			Words.addFirst(easy[qNum]);

			// add element at the beginning of linked list
			Words.add(medium[qNum]);

			// add element at the end of linked list
			Words.addLast(hard[qNum]);
			System.out.println("Terms: " + Words);

			variables();
			//  System.out.println(easy[0]); // this was a test lol
		}
		// Checks with method to see if it is a palindrome
		if (Words.checkWord()) {
			// System.out.println("It is a Palindrome");
			jlabel.setText("you right g, next term");
			jlabel.setVisible(true);


		} else {
			// System.out.println("It is not a Palindrome");
			jlabel.setText("you wrong fr");
			jlabel.setVisible(true);
		}

	}



	//	static void linkedList() {
	//		  Random random = new Random(); 
	//			qNum = random.nextInt(5);
	//			
	//		  terms();
	//	    // create a linked list using the LinkedList class
	//	    LinkedList<String> Words = new LinkedList<>();
	//
	//	    // Add elements to LinkedList
	//	  //  Words.add("Dog");
	//	    Words.addFirst(easy[qNum]);
	//
	//	    // add element at the beginning of linked list
	//	    Words.add(medium[qNum]);
	//
	//	    // add element at the end of linked list
	//	    Words.addLast(hard[qNum]);
	//	    System.out.println("Terms: " + Words);
	//	   
	//	    variables();
	//	  //  System.out.println(easy[0]); // this was a test lol
	//	}
	public boolean checkWord() {


		return true;

	}

	public static void main(String[] args){

		variables();


	}

}



