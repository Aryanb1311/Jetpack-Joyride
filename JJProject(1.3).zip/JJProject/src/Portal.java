import java.awt.*;

import java.awt.event.*;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.*;

/// SPRITES WILL BE ADDED LATER!!!! or not lol
//-------Connect it to IMG folder with sprites ****
public class Portal extends JFrame implements ActionListener {

	obstacle Missile;
	Graphics graphics;
	private ImageIcon image1; // this will be replaced with a sprite later on called PC (in a separate folder)
	private JLabel label1;

	private static int mw = 400;
	private static int mh = 400;

	// variables for bullet
	int width = 400; 
	int height = 400;
	int x = 1000;
	int y =100;
	int w = 10;
	int color = 33;
	int portalSizeX = 25;
	int portalSizeY = 275;
	int speed =1;
	int v=0; // test
	int PortalSizeX = 100;
	int PortalSizeY = 70;

	panel panel = new panel();
	// this is for text effect
	JLabel mechaTalk = new JLabel("Enter Boss Level Portal!");
	int lblTextLength =0;
	Timer tm;
	int counter = 0;

	/**
	 * @wbp.nonvisual location=46,61
	 */
	private final JButton button = new JButton("New button");



	void gameWin() { // if the user wins they are sent to this screen


		x = -1000;
		JLabel youWinLbl = new JLabel("YOU WIN! +1 LIFE");
		Dimension size = youWinLbl.getPreferredSize();
		youWinLbl.setBounds(100, 150, size.width, size.height);
		panel.add(youWinLbl);
		youWinLbl.setVisible(true);
		mechaTalk.setVisible(false);
		System.out.println("win screen activated");
		// add a life here but we gotta combine the files in order to do that lol
	}


	void PortalAppear() { 
		// this is where the missile functions are
		ActionListener movement = new AbstractAction() {
			/// horizontal movement of Portal

			public void actionPerformed(ActionEvent e) {
				//shoot it left
				if (x <= 1000){
					x-=50;

					//	System.out.println(x); // v will stop at 6		
					panel.repaint();
				}  




				if (x <= -40) { /// this is the part where the missile is off screen


					v++;

					x = 400;


					/// for the amount of Portal attacks done 
					if (v == 1) {
						y =200;
						//						v++;
						System.out.println("lemme test something hellooooo");
					} else if (v == 2) {
						y = 300; 
						//						v++;
						System.out.println("v = "+ v);
					} else if (v == 3) {
						y = 150;
						//						v++;
						System.out.println("v = "+ v);

					} else if (v>3) {
						y = 75;
						System.out.println("v = "+ v);

					} else if(v > 3 ) {
						if (level == 0) {
							level++;
							v=0;
						} else if ( level == 1) {
							//								v=0;
							y=200;
							level++;
							v=0;
						} else if (level == 2){
							System.out.println("No more levels added");
							level++;
							y=200;
							v=0;
						} else if (level > 2) {
							y=-1000;

							gameWin();
						}

						panel.repaint();
						//v++;

					}
				}

			};

		};
			Timer speed = new Timer(w, movement); // 1 second 

			speed.start();
			getContentPane().add(panel);

			//	}

			pack();
			setDefaultCloseOperation(EXIT_ON_CLOSE);
			setVisible(true);

		}

		public Portal()  {// calling for the Portal to be shot
			// little talk scene because why not


			PortalAppear();



		}

		private class panel extends JPanel {

			protected void paintComponent(Graphics g) { // square will be replaced with image sprites // maybe do a swap();
				Graphics2D g2 = (Graphics2D) g;
				super.paintComponent(g);


				g.setColor(Color.BLUE);
				g.fillOval(x, y, 70, 90);


			}
			public Dimension getPreferredSize() {
				return new Dimension(mw, mh);
			}
		}

		public static void main(String[] args) {
			EventQueue.invokeLater(new Runnable() {
				public void run() {
					new Portal();
				}
			});
		}


		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub

		}


	}
