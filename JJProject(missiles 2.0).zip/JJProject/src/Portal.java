import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.Random;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class Portal extends JFrame {
	int width, height = 400;
	int x;
	int portalSize = 60;
	Random random = new Random();
	int y = random.nextInt(390);


	class panel extends JPanel {

		protected void paintComponent(Graphics g) { // square will be replaced with image sprites // maybe do a swap();
			Graphics2D g2 = (Graphics2D) g;
			super.paintComponent(g);

			g.fillOval(portalSize, portalSize, 20, 7);

		}
		public Dimension getPreferredSize() {
			return new Dimension(width, height);
		}

	} 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Portal();
		

	}

}
