import java.awt.*;

import java.awt.event.*;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.*;

/// SPRITES WILL BE ADDED LATER!!!! or not lol
//-------Connect it to IMG folder with sprites ****
public class Missiles extends JFrame implements ActionListener {

	obstacle Missile;
	Graphics graphics;
	private ImageIcon image1; // this will be replaced with a sprite later on called PC (in a separate folder)
	private JLabel label1;

	private static int mw = 400;
	private static int mh = 400;

	// variables for bullet
	int x = 400;
	int y = 100;
	int w = 10;  // movement on timer function

	int v = 0; // this is just a test thing
	//nvm nah	boolean done = false; // if this is true, then the code will stop and bring them to the game win screen

	int level = 0; // the difficulty of the level
	int numMissiles =0; // counts the number of missiles the boss has shot
	int speed = 1; //starting speed, increases per boss

	///
	static int position[] = {300, 100, 130, 170}; // array for the positions the missiles will shoot from

	int MissileX, MissileY;

	panel panel = new panel();
	// this is for text effect
	JLabel mechaTalk = new JLabel("Mecha-Ray-A-Thon Boss: Avoid all Missiles! ");
	int lblTextLength =0;
	Timer tm;
	int counter = 0;

	/**
	 * @wbp.nonvisual location=46,61
	 */
	private final JButton button = new JButton("New button");



	void gameWin() { // if the user wins they are sent to this screen
		

 x = -1000;
		JLabel youWinLbl = new JLabel("YOU WIN! +1 LIFE");
		Dimension size = youWinLbl.getPreferredSize();
		youWinLbl.setBounds(100, 150, size.width, size.height);
		panel.add(youWinLbl);
		youWinLbl.setVisible(true);
		 mechaTalk.setVisible(false);
		System.out.println("win screen activated");
		// add a life here but we gotta combine the files in order to do that lol
	}

	void introScene() {
	
		// first, the player sees this screen and is prompted on what to do.
		Dimension size = mechaTalk.getPreferredSize();
		mechaTalk.setBounds(100, 150, size.width, size.height);
		mechaTalk.setVisible(true);
		panel.add(mechaTalk);	

		String txt = mechaTalk.getText();
		lblTextLength = txt.length();

		tm = new Timer(25, new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				counter++;
				if (counter > lblTextLength) {
					//counter =0;
					tm.stop();
				} else {
					mechaTalk.setText(txt.substring(0,counter));
					
				}
			}	
			
		});
		tm.start();
		
	}


	void missileStart() { 
		// this is where the missile functions are
		ActionListener movement = new AbstractAction() {
			/// horizontal movement of missiles

			public void actionPerformed(ActionEvent e) {
				//shoot it left
				if (x <= 400){

					if (level == 0) { // easy level missiles
						x -= 5;
							System.out.println("start of level 1 missile");
					} else if (level == 1) { // medium level missiles
						x-= 9;
							System.out.println("start of level 2 missile");
					} else if (level >= 2) { // hard level missiles
						x-=15;
							System.out.println("start of level 3+ missile");
					}
					//	System.out.println(x); // v will stop at 6		
					panel.repaint();
				}  




				if (x <= -40) { /// this is the part where the missile is off screen
					try {
						if (level == 0) { // changing the time difference for easy/medium/hard so bullets shoot faster the higher the level
							Thread.sleep(2000); 
							
						} else if (level == 1) {
							Thread.sleep(1000);
							
						} else if (level >= 2) {
							Thread.sleep(0750);
						}

					} catch (InterruptedException e1) {

						e1.printStackTrace();
						x= -45; // brings the missiles off screen
					}
				
					numMissiles++;

					x = 400;
					System.out.println("Number of missiles= " +numMissiles + " level: " + level);


					/// for the amount of missiles attacks done 
					if (numMissiles == 1) {
						y =200;
//						v++;
						System.out.println("lemme test something hellooooo");
					} else if (numMissiles == 2) {
						y = 300; 
//						v++;
						System.out.println("v = "+ v);
					} else if (numMissiles == 3) {
						y = 150;
//						v++;
						System.out.println("v = "+ v);
						
					} else if (numMissiles == 4) {
						y = 75;
						System.out.println("v = "+ v);
						
					} else if(numMissiles > 3 ) {
						if (level == 0) {
							level++;
							numMissiles=0;
						} else if ( level == 1) {
//								v=0;
								y=200;
								level++;
								numMissiles=0;
						} else if (level == 2){
							System.out.println("No more levels added");
							level++;
							y=200;
							numMissiles=0;
						} else if (level > 2) {
							y=-1000;
							
							gameWin();
						}

						panel.repaint();
						//v++;
						System.out.println("level: " + level);
					}
				}

			};
		};
	

		Missile = new obstacle (MissileX, MissileY, x, y, Color.GRAY);
		Timer speed = new Timer(w, movement); // 1 second 

		speed.start();
		getContentPane().add(panel);

		//	}

		pack();
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);

	}

	public Missiles()  {// calling for the missiles to be shot
		// little talk scene because why not
		ImageIcon titleImage;
		introScene();

		missileStart();
	
		
		
	}
	
	private class panel extends JPanel {

		protected void paintComponent(Graphics g) { // square will be replaced with image sprites // maybe do a swap();
			Graphics2D g2 = (Graphics2D) g;
			super.paintComponent(g);

			// mecha ray a thon graphics
			g.fillRect(300, 110, 100, 203);  // body
			g.fillRect(320, 50, 70, 75); // head
			g.fillRect(310, 310, 20, 80); // legs
			g.fillRect(380, 310, 20, 80); // legs
			g.fillRect(280, 380, 50, 20); // feet
			g.fillRect(350, 380, 50, 20); // feet
			g.fillRect(240, 130, 60, 20);
			//the missiles graphics 
			g.fillRect(x, y, 20, 7);
			
			
		}
		public Dimension getPreferredSize() {
			return new Dimension(mw, mh);
		}
	}

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				new Missiles();
			}
		});
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

	}


}
