import java.awt.*;

import java.awt.event.*;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.*;

/// SPRITES WILL BE ADDED LATER!!!! or not lol
//-------Connect it to IMG folder with sprites ****
public class Missiles extends JFrame implements ActionListener {

	obstacle Missile;
	Graphics graphics;
	private ImageIcon image1; // this will be replaced with a sprite later on called PC (in a separate folder)
	private JLabel label1;

	private static int mw = 400;
	private static int mh = 400;

	// variables for bullet
	int x = 400;
	int y = 100;
	int w = 10;  // movement on timer function

	int v = 0; // this is just a test thing
//nvm nah	boolean done = false; // if this is true, then the code will stop and bring them to the game win screen

	int level = 0; // the difficulty of the level
	int numMissiles =0; // counts the number of missiles the boss has shot
	int speed = 1; //starting speed, increases per boss

	///
	static int position[] = {300, 100, 130, 170}; // array for the positions the missiles will shoot from

	int MissileX, MissileY;

	panel panel = new panel();
	JLabel mechaTalk = new JLabel("Mecha-Ray-A-Thon Boss: Avoid all the Missiles!");
	/**
	 * @wbp.nonvisual location=46,61
	 */
	private final JButton button = new JButton("New button");



	void gamewin() { // if the user wins they are sent to this screen
	
		JLabel youWinLbl = new JLabel("YOU WIN! +1 LIFE");
		Dimension size = youWinLbl.getPreferredSize();
		youWinLbl.setBounds(100, 150, size.width, size.height);
		panel.add(youWinLbl);
		youWinLbl.setVisible(true);
		System.out.println("win screen activated");
		// add a life here but we gotta combine the files in order to do that lol
	}

	void introScene() {
		// first, the player sees this screen and is prompted on what to do.
		Dimension size = mechaTalk.getPreferredSize();
		mechaTalk.setBounds(100, 150, size.width, size.height);
		mechaTalk.setVisible(true);
		panel.add(mechaTalk);	
		
	}
	
	
	void missileStart() { 
		// this is where the missile functions are
			ActionListener movement = new AbstractAction() {
				/// horizontal movement of missiles

				public void actionPerformed(ActionEvent e) {
					//shoot it left
					if (x <= 400){
						
						if (level == 0) { // easy level missiles
							x -= 5;
						//	System.out.println("start of level 1 missile");
						} else if (level == 1) { // medium level missiles
							x-= 9;
						//	System.out.println("start of level 2 missile");
						} else if (level >= 2) { // hard level missiles
							x-=15;
						
						//	System.out.println("start of level 3+ missile");
						}
						//	System.out.println(x); // v will stop at 6		
						panel.repaint();
					}  

					
					
					
					if (x <= -40) { /// this is the part where the missile is off screen
						try {
							if (level == 0) { // changing the time difference for easy/medium/hard so bullets shoot faster the higher the level
								Thread.sleep(2000); 
								mechaTalk.setVisible(false);
							} else if (level == 1) {
								Thread.sleep(1000);
								mechaTalk.setVisible(false);
							} else if (level >= 2) {
								Thread.sleep(0750);
								mechaTalk.setVisible(false);
							}

						} catch (InterruptedException e1) {
							
							e1.printStackTrace();
							x= -45; // brings the missiles off screen
						}
						numMissiles++;
						System.out.println("reset" + x);
						x = 400;
						System.out.println("Number of missiles= " +numMissiles + "level: " + level);
						v++;

						/// for the amount of missiles attacks done 
						if (numMissiles == 1) {
							y =200;
							v++;
							System.out.println("lemme test something hellooooo");
						} else if (numMissiles == 2) {
							y = 300; 
							v++;
							System.out.println("v = "+ v);
						} else if (numMissiles == 3) {
							y = 150;
							v++;
							System.out.println("v = "+ v);
						} else if(numMissiles > 3 || v ==3) {
							if (level < 2 || v==3) {
								
								v=0;
								level++;
								System.out.println("added level");
								// sends them to the game win screen
								// increases the level for the future battle
								
							} else if (level >= 3){
								System.out.println("No more levels added");
								v=0;
							}
						
							panel.repaint();
							//v++;

						}
					}
				
			};
			};
			

			Missile = new obstacle (MissileX, MissileY, x, y, Color.GRAY);
			Timer speed = new Timer(w, movement); // 1 second 

			speed.start();
			getContentPane().add(panel);

			//	}

			pack();
			setDefaultCloseOperation(EXIT_ON_CLOSE);
			setVisible(true);

		}
		
	
	
	
		public Missiles()  {// calling for the missiles to be shot
			// little talk scene because why not
				introScene();
				missileStart();
		}


		private class panel extends JPanel {

			protected void paintComponent(Graphics g) { // square will be replaced with image sprites // maybe do a swap();
				Graphics2D g2 = (Graphics2D) g;
				super.paintComponent(g);
				
				// mecha ray a thon graphics
				g.fillRect(275, 110, 100, 203); 
				g.fillOval(290, 50, 70, 75);
				//the missiles graphics
				g.fillRect(x, y, 20, 7);

			}
			public Dimension getPreferredSize() {
				return new Dimension(mw, mh);
			}
		}

		public static void main(String[] args) {
			EventQueue.invokeLater(new Runnable() {
				public void run() {
					new Missiles();
				}
			});
		}

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub

		}


	}
