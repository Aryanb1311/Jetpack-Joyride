import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class ChemicolliaGUI {
	static JLabel label;
	static JButton Enter;
	static JTextArea textarea;
	static JTextField textfield;
	static JPanel panel;

	public static void main(String[] args) { 
		JFrame frame = variables(); //importing variables to JFrame and making JFrame visible
		frame.setVisible(true);
	}

	public static JFrame variables() {
		textfield = new JTextField();
		textarea = new JTextArea(5, 20);
		label = new JLabel("SPELL: TEST"); // text prompting user for input
		Enter = new JButton("Enter"); // buttons for user to guess with

		panel = new JPanel(); // creates new panel for the interface
		panel.setBorder(BorderFactory.createEmptyBorder(30, 30, 10, 30)); //panel dimensions
		panel.add(label);
		panel.add(textfield);
		panel.add(textarea);
		panel.add(Enter); // adding number and quit/new game/score buttons to panel

		JFrame frame = new JFrame(); // creates new frame for the panel
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);// exits program upon closing the window
		frame.setSize(300, 300); //setting frame dimensions
		frame.getContentPane().add(panel); //adding panel to frame
		return frame;
	}

	public static void inGame() { //main method assigning actions to variables
		Enter.addActionListener(new ActionListener() { //if enter is pressed
			public void actionPerformed(ActionEvent a) {
				String text = textfield.getText();
				System.out.print(text);
			}
		});
	}

	public void keyPressed(KeyEvent k) {

		switch(k.getKeyCode()) {
		case KeyEvent.VK_ENTER:
			// this isn't going to work without the linked list to store the user's answers in
			break;
		}
	}
	
	//timer needs to be implemented, easy/medium/hard options need to be implemented

}
