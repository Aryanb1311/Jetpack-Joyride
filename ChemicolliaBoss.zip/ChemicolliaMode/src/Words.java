public class Words {
	
	static String [] easy = new String [5];
	static String [] medium = new String [5];
	static String [] hard = new String [5];
	
	static void main(String[]args){
	
	terms();
		
	}
	
	public static void terms() {
	//easy terms for boss
	easy[0] = "matter";
	easy[1] = "atom";
	easy[2] = "mixture";
	easy[3] = "proton";
	easy[4] = "electron";

	//medium terms for boss
	medium[0] = "Azimuthal";
	medium[1] = "covalent";
	medium[2] = "Oxidation";
	medium[3] = "Reaction";
	medium[4] = "Molecules";
	
	//hard terms for boss
	hard[0] = "phenolphthalein";
	hard[1] = "paracetamol";
	hard[2] = "pneumonoultramicroscopicsilicovolcanoconiosis";
	hard[3] = "equillibrium";
	hard[4] = "Tetrahedral";
	} 
}
