/* more of the game fleshed out, also because i assume we'd need inheritance
 * to spell check the user's input
 */
import java.util.Timer;
import java.util.TimerTask;

public class ChemCountdown {
    public static void main(String[] args) {

        Timer timer = new Timer(); //set up a new timer ykyk

        timer.scheduleAtFixedRate(new TimerTask() {
            int c = 20; //countdown starts at 20sec

            public void run() {

                System.out.print("Countdown: " + c + System.lineSeparator());
                c--;

                if (c < 0) {
                    timer.cancel();
                    System.out.print("Time's up!");
                }
            }
        }, 0, 1000); //controls how fast the countdown goes down
    }
}
