import java.util.Timer;
import java.util.TimerTask;

class Stopwatch1 {
	private final long nanoSecondsPerSecond = 1000000000;

	private long watchStart = 0;
	private long watchStop = 0;
	private boolean stopWatchRunning = false;


	public void start () {
		this.watchStart = System.nanoTime();
		this.stopWatchRunning = true;
	}


	public void stop () {
		this.watchStop = System.nanoTime();
		this.stopWatchRunning = false;
	}

	// figuring out how to modify this chunk to use for scenery
	/*public long getElapsedSeconds() {
        long elapsedTime;

        if (stopWatchRunning)
            elapsedTime = (System.nanoTime() - watchStart);
        else
            elapsedTime = (watchStop - watchStart);

        return elapsedTime / nanoSecondsPerSecond;
    }*/

}


public class HighScore {

	public static void main(String[] args) {

		Stopwatch1 highScore = new Stopwatch1();
		highScore.start();
		highScore.stop();

		Timer timer = new Timer();
		        timer.scheduleAtFixedRate(new TimerTask() {
			int c = 0;

			public void run() {
				System.out.print("Score: " + c + System.lineSeparator());
				c++;
				}
		}, 0, 500);		//System.out.println("Elapsed time in seconds: " + highScore.getElapsedSeconds())
    }
}