import java.awt.*;
import javax.swing.*;
import java.io.File;

import javax.imageio.ImageIO;


public class Player extends Rectangle {
	
	
	private int dx, dy;
	
	public Player(int x, int y, int width, int height, int dx, int dy) {
		setBounds(x, y, width, height);
		
		
		this.dy = dy;
	}
	public void tick() {
		
		this.y += dy;
	}
	/**
	 * Method for creating the graphics of the game
	 */
	public void draw(Graphics g) {
		g.fillRect(this.x, this.y, this.width, this.height);
	}
	
	public void setDx(int dx) {
		this.dx = dx;
	}
	public void setDy(int dy) {
		this.dy = dy;
	} 
}
