import java.awt.*;

import javax.swing.ImageIcon;

public class Immortal extends Rectangle  
{
	
	private int dx, dy;


	public Immortal(int x, int y, int width, int height, int dx, int dy) {
		setBounds(x, y, width, height);
		
		this.dx = dx;
		this.dy = dy;
	}
	
	
	public void tick() {
		this.x += dx;
		
	}
	
	public void draw(Graphics g) {
		g.setColor(Color.BLUE);
		g.fillRect(this.x, this.y, this.width, this.height);
	}

	public void setDx(int dx) {
		this.dx = dx;
	}
	public void setDy(int dy) {
		this.dy = dy;
	} 
	
	

	
/*
	public void time() {
		
	}
	
	public void clearObst() {
		
	}
	
	public void shield() {
		
	}
	
*/
}
