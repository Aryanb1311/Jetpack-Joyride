import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JPanel; 
import javax.swing.Timer;
/**
 * a helper class for the player to implement movement logic

 * @author Topsav
 *
 */
public class Powerup extends JPanel implements ActionListener, KeyListener {
	
	Timer t = new Timer(7, this);
	Immortal p = new Immortal(390, 10, 15, 15, 0, 0);
	
	public Powerup() {
		addKeyListener(this);
		setFocusable(true);
		
		t.start();
	}
	public void actionPerformed(ActionEvent arg0) {
		
		p.tick();
		
		repaint();
	}
	/**
	 * method called automatically on start which clears the current position of the rectangle and moving in negative x direction
	 * and redrawing.
	 */
	public void paint(Graphics g) {
		g.clearRect(0, 0, getWidth(), getHeight());
		
		//p.setDx(1);
		
		p.setDx(-1);
		
		p.draw(g);
	}
	public void keyTyped(Graphics g) {
		g.clearRect(0, 0, getWidth(), getHeight());
		
		p.draw(g);
	}

	/**
	 * 
	 */
	public void keyPressed(KeyEvent k) {
	
		}
	

	
	public void keyReleased(KeyEvent k) {
		
		}
		
	
	
	public void keyTyped(KeyEvent arg0) {
		
		
	}
 
}
