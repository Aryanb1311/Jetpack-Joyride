

public class Name {
	
		public String name;
		
		public Name()
		{
			
		}
		
		// Fighter first constructor
		public Name(String name)
		{
			this.name = name;
		}
		
		public void setName(String defName) // set Name 
		{
			name = defName;
		}
		
		public String getName() // get Name
		{
			return name;
		}
		
		public void getUserName() // get Fighter
		{
			System.out.println("My username is " + name + "" + "." ); // fighter statement
		}
		
	
}
