import java.awt.*;
import java.awt.event.*;
import java.awt.geom.AffineTransform;

import javax.swing.*;
//corruptpc (1.2)
/// SPRITES WILL BE ADDED LATER!!!! or not 
//-------Connect it to IMG folder with sprites ****
public class CorruptPc extends JFrame implements ActionListener {

	obstacle corruptPc;
	Graphics graphics;
	Image Pc1; // this will be replaced with a sprite later on called PC (in a separate folder)


	private static int CPW = 400;
	private static int CPH = 400;
	int x = 130;
	int y = 300;
	int w = 100; // the time the pc will take to move
	int v = 0; 
	int c = 50;

	int CorruptPcX, corruptPcY;

	panel panel = new panel();

	public CorruptPc() {

		ActionListener movement = new AbstractAction() {

			public void actionPerformed(ActionEvent e) {

				//move up
				if (y >= 240|| v==0){
					y -= 10;
					v++; // test
					System.out.println("What : " + v ); // v will stop at 6				
					panel.repaint();
				}  // move down
				if (v >= 6 || y==240) { 
					/// once it reaches its max point, this is where the attack happens.
					if(y==240) {
						// insert sprite change here, using swap??? 

						try {
							Thread.sleep(2000); // pause the graphics for 1 seconds
						} catch (InterruptedException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
					// move back down until off screen
					y -= -20;
					v++;
					System.out.println(y);
					// swap back to other sprite sprite here
					System.out.println("moving down");

				}
			}

			void attack() {
				ActionListener movement2 = new AbstractAction() {

					public void actionPerformed(ActionEvent e) {

						if (v >= 6 || y==240) { 
							/// once it reaches its max point, this is where the attack happens.
							// insert sprite change here, using swap??? 
							try {
								Thread.sleep(2000); // pause the graphics for 1 seconds
							} catch (InterruptedException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}

							// move back down until off screen
							y -= -20;
							System.out.println(y);
							// swap back to other sprite sprite here
							System.out.println("moving down");

						}
					}
				};
				Timer speed2 = new Timer(w, movement2); // for 
			};
		};
		
		corruptPc = new obstacle (CorruptPcX, corruptPcY, x, y, Color.BLACK); // made it black because the obstacles are all gonna be black so they dont mix up the powerups

		
		
		Timer speed = new Timer(w, movement); // 1 second 
		speed.start();
		add(panel);

		pack();
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
	}

	private class panel extends JPanel {
		
		protected void paintComponent(Graphics g) { // square will be replaced with image sprites // maybe do a swap();
			Graphics2D g2 = (Graphics2D) g;
			super.paintComponent(g);
			//the computer
				g.fillRect(x, y, 90, 60);
				g.fillRect(x+35, y, 20, 100);
				g.fillRect(x, y+90, 90, 10);

			//wires
			if (v >  4 && v < 18) { // if its greater than 4 but less than 20 , the wires shows 
			g.drawLine(x+33,y+30,70,200);
			g.drawLine(x+20,y+20,50,100);
			g.drawLine(x+30,y+0,90,150);
			} 
			

		}

		public Dimension getPreferredSize() {
			return new Dimension(CPW, CPH);
		}
	}

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				new CorruptPc();
			}
		});
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

	}


}
