import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.JComboBox;

public class userName extends JFrame {

	private JPanel contentPane;
	private JTextField nameTextField;
	
	public Name userName = new Name();
	
	//Arrays
	Name userNames[] = new Name[100];
	
	//Variables
	public int user1Counter = 0;
	String name = ""; // name
	String nameSelected = " ";
	
	boolean editing = false;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					userName frame = new userName();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public userName() {
		setTitle("Jetpack Joyride Main Menu"); // Name of JFrame
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 450);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblName = new JLabel("username"); // username label
		lblName.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblName.setBounds(10, 27, 73, 13);
		contentPane.add(lblName);
		
		nameTextField = new JTextField(); // username text field
		nameTextField.setBounds(93, 25, 96, 19);
		contentPane.add(nameTextField);
		nameTextField.setColumns(10);
		
		JButton btnAdd = new JButton("Add"); // Add Bttn
		btnAdd.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnAdd.setBounds(187, 107, 73, 23);
		contentPane.add(btnAdd);
		
		JButton btnSave = new JButton("Save"); // Save Button
		btnSave.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnSave.setBounds(10, 107, 84, 23);
		contentPane.add(btnSave);
		
		JButton btnDeleteUserName = new JButton("Delete"); // Delete bttn
		btnDeleteUserName.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnDeleteUserName.setBounds(104, 107, 73, 23);
		contentPane.add(btnDeleteUserName);
		
		JComboBox viewCB = new JComboBox();
		viewCB.setModel(new DefaultComboBoxModel(new String[] {"Select"}));
		viewCB.setBounds(303, 44, 123, 21);
		contentPane.add(viewCB);
		
		JLabel lblUser = new JLabel("User");
		lblUser.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblUser.setBounds(335, 27, 45, 13);
		contentPane.add(lblUser);
		
		JLabel lblInstructions = new JLabel("Instructions");
		lblInstructions.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblInstructions.setBounds(10, 173, 89, 13);
		contentPane.add(lblInstructions);
		
		JButton btnInstructions = new JButton("View Instructions");
		btnInstructions.setBounds(10, 197, 116, 31);
		contentPane.add(btnInstructions);
		
		JLabel lblInstructionsMove = new JLabel("-Press spacebar to go up and let go of spacebar to go down");
		lblInstructionsMove.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblInstructionsMove.setBounds(20, 240, 360, 13);
		contentPane.add(lblInstructionsMove);
		lblInstructionsMove.setVisible(false);
		
		JLabel lblInstructionScore = new JLabel("-Your score is based on how long you are alive for and the bosses you defeat");
		lblInstructionScore.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblInstructionScore.setBounds(10, 263, 449, 31);
		contentPane.add(lblInstructionScore);
		lblInstructionScore.setVisible(false);
		
		JButton btnPlay = new JButton("Play");
		btnPlay.setBounds(335, 107, 73, 43);
		contentPane.add(btnPlay);
		
		JLabel lblInstructionSceneryBoss = new JLabel("-Each scenery except for default has a boss that you have to defeat and you will be granted 1 life for defeating the boss");
		lblInstructionSceneryBoss.setFont(new Font("Tahoma", Font.PLAIN, 10));
		lblInstructionSceneryBoss.setBounds(10, 304, 576, 13);
		contentPane.add(lblInstructionSceneryBoss);
		lblInstructionSceneryBoss.setVisible(false);
		
		JLabel lblInstructionObstacle = new JLabel("-If you hit a obstacle you will lose 1 life and if you run out of lives you lose");
		lblInstructionObstacle.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblInstructionObstacle.setBounds(10, 340, 425, 13);
		contentPane.add(lblInstructionObstacle);
		lblInstructionObstacle.setVisible(false);
		
		// Add button listener
				btnAdd.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						btnSave.setVisible(true); // sets bttns edit, view, and delete to not enabled
						btnDeleteUserName.setVisible(true);
						
						btnSave.setEnabled(false); // sets bttns edit, view, and delete to not enabled
						btnDeleteUserName.setEnabled(false);
					}
				});
				
		// Save Button Listener 
				btnSave.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {

						name = nameTextField.getText(); // gets name
						
						// sets invisible
						lblName.setVisible(false);
						nameTextField.setVisible(false);
						btnSave.setVisible(false);
						
					}
				});
				
				// Delete Fighter button listener
				btnDeleteUserName.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						
						nameSelected = (String) viewCB.getSelectedItem();

						for (int i = 0; i < user1Counter; i++) // Saiyan Fighter search
						{
							System.out.println(userNames[i]userNames(.getName())); // troubleshoot print line

							if (nameSelected.equals(userNames[i].getName())) // Runs If name of fighter saiyan matched
							{
								viewCB.removeItem(userNames[i].getName()); // remove saiyan name from view combobox
								for (int n = i; n < user1Counter - 1; n++) // subtract saiyan counter by 1, remove item from array and shift items
								{
									userNames[n] = userNames[n + 1];
								}
								user1Counter--; // reduce number of saiyan1 fighters by 1
							} // name match
						} // saiyan1
						// reset
						
						nameTextField.setText(null);

						btnDeleteUserName.setVisible(false); // sets fighter, view, confirm and cancel to visible
						btnSave.setVisible(false);
					}
				}); // delete fighter button
				
				// Add button listener
				btnInstructions.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						btnSave.setVisible(true); // sets bttns edit, view, and delete to not enabled
						btnDeleteUserName.setVisible(true);
						
						btnSave.setEnabled(false); // sets bttns edit, view, and delete to not enabled
						btnDeleteUserName.setEnabled(false);
						nameTextField.setEnabled(false);
						viewCB.setEnabled(false);
						
						lblInstructionsMove.setVisible(false);
						lblInstructionScore.setVisible(false);
						lblInstructionSceneryBoss.setVisible(false);
						lblInstructionObstacle.setVisible(false);
					}
				});			
	}
}
