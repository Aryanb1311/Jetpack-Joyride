public class Shield extends JOJO
{
	public boolean tempShield;

	public Shield()
	{
		this.name = "";
		this.lives = 0; 
		this.score = 0;
		this.highscore = 0;
		this.verSpeed = 0;
		this.tempShield = false;
	}
	
	public Shield(String name, int lives, int score, int highscore, int verSpeed, int horSpeed, int timeSlowDown, int tempShield)
	{
		this.name = name;
		this.lives = lives;
		this.score = score;
		this.highscore = highscore;
		this.verSpeed = verSpeed;
		this.tempShield = false;
	}
	
	
	public void setShield (boolean tempShield) 
	{ 
		this.tempShield = true;
	}


	public boolean getShield () 
	{
		return this.tempShield = true;
	}

}
