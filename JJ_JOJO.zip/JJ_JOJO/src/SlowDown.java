public class SlowDown extends JOJO
{
	public int horSpeed, timeSlowDown;

	public SlowDown()
	{
		this.name = "";
		this.lives = 0; 
		this.score = 0;
		this.highscore = 0;
		this.verSpeed = 0;
		this.horSpeed = 0;
		this.timeSlowDown = 0;
	}
	
	public SlowDown(String name, int lives, int score, int highscore, int verSpeed, int horSpeed, int timeSlowDown)
	{
		this.name = name;
		this.lives = lives;
		this.score = score;
		this.highscore = highscore;
		this.verSpeed = verSpeed;
		this.horSpeed = horSpeed;
		this.timeSlowDown = timeSlowDown;
	}
	
	
	public void setHorSpeed (int horSpeedValue) 
	{ 
		this.horSpeed = horSpeedValue;
	}
	public void setTimeSLow (int timeSlowValue)
	{
		this.timeSlowDown = timeSlowValue;
	}


	public int gethorSpeed ( ) 
	{
		return this.horSpeed;
	}
	public int getTimeSlow ( ) 
	{
		return this.timeSlowDown;
	}

}
