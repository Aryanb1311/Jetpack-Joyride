public class ClearObstacle extends JOJO
{
	public int timeObstacleClear;

	public ClearObstacle()
	{
		this.name = "";
		this.lives = 0; 
		this.score = 0;
		this.highscore = 0;
		this.verSpeed = 0;
		this.timeObstacleClear = 0;
	}
	
	public ClearObstacle(String name, int lives, int score, int highscore, int verSpeed, int horSpeed, int timeSlowDown, int timeObstacleClear)
	{
		this.name = name;
		this.lives = lives;
		this.score = score;
		this.highscore = highscore;
		this.verSpeed = verSpeed;
		this.timeObstacleClear = timeObstacleClear;
	}
	
	
	public void setObstacleClear (int obstacleClearValue) 
	{ 
		this.timeObstacleClear = obstacleClearValue;
	}


	public int getObstacleClear ( ) 
	{
		return this.timeObstacleClear;
	}

}
