public class JOJO 
{
	public String name;
	public int lives, score, highscore, verSpeed;

	public JOJO()
	{
		name = "";
		lives = 0; 
		score = 0;
		highscore = 0;
		verSpeed = 0;
	}
	 
	public JOJO(String userName, int begLives, int begScore, int begHighscore, int begVerSpeed)
	{
		name = userName;
		lives = begLives;
		score = begScore;
		highscore = begHighscore;
		verSpeed = begVerSpeed;
	}

	
	public void setName (String nameValue)
	{
		name = nameValue;
	}
	public void setLives (int livesValue) 
	{ 
		lives = livesValue;
	}
	public void setScore (int scoreValue) 
	{ 
		score = scoreValue;
	}
	public void setHighscore (int highscoreValue) 
	{ 
		highscore = highscoreValue;
	}
	public void setverSpeed (int verSpeedValue) 
	{ 
		verSpeed = verSpeedValue;
	}

	
	public String getName () 
	{
		return name;
	}
	public int getLives () 
	{
		return lives;
	}
	public int getScore () 
	{
		return score;
	}
	public int getHighscore () 
	{
		return highscore;
	}
	public int getverSpeed () 
	{
		return verSpeed;
	}
	

}
