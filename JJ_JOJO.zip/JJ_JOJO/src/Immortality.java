public class Immortality extends JOJO
{
	public int timeImmortality;

	public Immortality()
	{
		this.name = "";
		this.lives = 0; 
		this.score = 0;
		this.highscore = 0;
		this.verSpeed = 0;
		this.timeImmortality = 0;
	}
	
	public Immortality(String name, int lives, int score, int highscore, int verSpeed, int horSpeed, int timeSlowDown, int timeImmortality)
	{
		this.name = name;
		this.lives = lives;
		this.score = score;
		this.highscore = highscore;
		this.verSpeed = verSpeed;
		this.timeImmortality = timeImmortality;
	}
	
	
	public void setTimeImmortality (int timeImmortalityValue) 
	{ 
		this.timeImmortality = timeImmortalityValue;
	}


	public int getTimeImmortality ( ) 
	{
		return this.timeImmortality;
	}

}
