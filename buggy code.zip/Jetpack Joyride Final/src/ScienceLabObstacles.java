//import libraries 
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.lang.Math;
import java.util.concurrent.TimeUnit;

public class ScienceLabObstacles extends JPanel implements ActionListener, KeyListener
{
	obstacles acidTurret;
	obstacles explodingBeaker;
	obstacles scientist;
	obstacles bullet;
	
	public int scientistX, scientistY;
	public int bulletX, bulletY;
	public int scientistWidth = 30, scientistHeight = 60;
	public int bulletWidth = 25, bulletHeight = 7;
	
	public boolean scientistC = false, bulletC = false, explodingBeakerC = false, acidTurretC = false;
	
	
	public int explodingBeakerWidth = 50, explodingBeakerHeight = 30; //height and width of exploding explodingBeaker obstacle 
	public int acidTurretWidth = 60, acidTurretHeight = 20; //height and width of the acidTurret turret obstacle 
	
	public int acidTurretX, acidTurretY; //instantiate x and y coordinates of the acidTurret turret 
	public int explodingBeakerX, explodingBeakerY; //instantiate and set x and y coordinates for the explodding explodingBeaker
	
	//timers
	public Timer explodingBeakerT, expansion; //timers for the exploding explodingBeaker obstacles 
	public Timer acidTurretT; //timer for the acidTurret turret obstacle 
	public Timer scientistT;
	public Timer game;
	
	Timer t = new Timer(10, this);
	Player p = new Player(30, 30, 30, 30, 0, 0);
	
	public int seconds = 1;
	
	public int speedInc;
	
	double a, b, c; //constants for the quadratic formula 
	
	
	public ScienceLabObstacles() 
	{
		addKeyListener(this);
        setFocusable(true);
       // requestFocusInWindow();
		
		t.start();
	}
	public void actionPerformed(ActionEvent arg0) {
		
		p.tick();
		
		repaint();
	}


	
	public void keyPressed(KeyEvent k) 
	{
		
		
		System.out.println("hola");

		switch(k.getKeyCode()) {
		case KeyEvent.VK_SPACE:
			p.setDy(-5);
			System.out.println("hola");

			break;
		}
	}

	
	public void keyReleased(KeyEvent k) {
		
		switch(k.getKeyCode()) {
		case KeyEvent.VK_SPACE:
			p.setDy(5);
			break;
		}
		
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	
	public void startGame()
	{
		game = new Timer(1000, this); //new timer for the object moving 

		game.addActionListener(new ActionListener()  //everytime the timer ticks it goes to this action listener 
		{
			public void actionPerformed(ActionEvent e) 
			{
				seconds++;
			}
		});
		game.start();

	}
	
	public void endGame()
	{
		game.stop();
		System.out.println(seconds);
	}
	
	public void paint(Graphics g)
	{
		
		g.clearRect(0, 0, getWidth(), getHeight());
		
		//draw the obstacles 
		if (acidTurretC)
		{
			acidTurret.draw(g);
		}
		if (explodingBeakerC)
		{
			explodingBeaker.draw(g);
		}
		if (scientistC)
		{
			scientist.draw(g);
			bullet.draw(g);
		}	
		p.draw(g);
			
	}//paint method ends
	
	
	
	public void startScientist()
	{
		scientistC = true; 
		
		scientistX = (Main.getFrameWidth() - 100);
		scientistY = (Main.getFrameHeight()/2);
		
		bulletY = (Main.getFrameHeight()/2);
		bulletX = scientistX;

		
		speedInc = 5;
		int bulletSpeed = 5;
		
		scientist = new obstacles (scientistX, scientistY, scientistWidth, scientistHeight, Color.BLUE); //graphic being instantiated 
		bullet = new obstacles (bulletX, bulletY, bulletWidth, bulletHeight, Color.GRAY); //graphic being instantiated 

		
		scientistT = new Timer(5, this); //new timer for the object moving 
		scientistT.addActionListener(new ActionListener()  //everytime the timer ticks it goes to this action listener 
        {
            public void actionPerformed(ActionEvent e) 
            {
            		if (scientistY > (Main.getFrameHeight()-scientistHeight) || scientistY <= 0) 
            		{
            			speedInc = -speedInc;
    				}
            		scientistY = scientistY - speedInc;
            		scientist.setLocation(scientistX, scientistY);
            		
            		if(bulletX >= -bulletWidth) //if in frame then only move 
                	{
                		bulletX = bulletX - bulletSpeed ; //changes the increments of the movement 
                		bullet.setLocation(bulletX, bulletY);
                	}//if ends 
            		else 
            		{
            			bulletX = scientistX;
            			bulletY = scientistY;
            		}
            		
            		checkCollision();
            		repaint();//repaints the obstacle 
            }  
        });
		scientistT.start(); //starts the timer 	
	}
	
	
	public void startExplodingBeaker(int speed, int rateOfExpansion) 
	{		
		explodingBeakerC = true;
		explodingBeakerY = Main.randomNumGenerator(0, (Main.getFrameHeight() - explodingBeakerHeight)); //get random Y in the size of the frame 
		
		explodingBeakerX = Main.getFrameWidth();
		
		explodingBeaker = new obstacles (explodingBeakerX, explodingBeakerY, explodingBeakerWidth, explodingBeakerHeight, Color.YELLOW); //graphic being instantiated 
		
		explodingBeakerT = new Timer(5, this); //new timer for the object moving 
		explodingBeakerT.addActionListener(new ActionListener()  //everytime the timer ticks it goes to this action listener 
        {
            public void actionPerformed(ActionEvent e) 
            {
            	if(explodingBeakerX >= -explodingBeakerWidth) //if in frame then only move 
            	{
            		explodingBeakerX = explodingBeakerX - speed ; //changes the increments of the movement 
            		explodingBeaker.setLocation(explodingBeakerX, explodingBeakerY);
            		
            		checkCollision();

            		
            		repaint();//repaints the obstacle 
            	}//if ends 
            }  
        });
		explodingBeakerT.start(); //starts the timer 
        
		expansion = new Timer(50, this); //new timer for the rate of expansion 
		expansion.addActionListener(new ActionListener()  //every time the timer ticks it goes to this action listener 
        {
            public void actionPerformed(ActionEvent e) 
            {
            	if(explodingBeakerX <  3*Main.getFrameWidth()/4) //only expand at 3/4 of the width of the frame
            	{
        		explodingBeakerWidth = explodingBeakerWidth + rateOfExpansion; //expand the width of the obstacle 
        		explodingBeakerHeight = explodingBeakerHeight + rateOfExpansion; //expand the height of the obstacle 
        		explodingBeaker.setSize(explodingBeakerWidth, explodingBeakerHeight);
        		
        		repaint(); //repaint the obstacle 
            	}
            }
        });
		expansion.start(); //start the timer 
	}//startExplodingBeaker method ends
	
	
	public void stopExplodingBeakerObstacle()
	{
		explodingBeakerT.stop(); //stops the timer 
		expansion.stop(); //stop the expansion 
		//sets the obstacle to the default size 
		explodingBeakerHeight = 30; 
		explodingBeakerWidth = 30; 
		explodingBeaker.setSize(explodingBeakerWidth, explodingBeakerWidth);
		repaint();
	} //stopExplodingBeakerObstacle method ends 
	
	
	
	
	
	public void stopAcidTurretObstacle()
	{
		acidTurretT.stop(); //stops the timer 
		repaint(); //repaint the obstacle
		
	} //stopAcidTurretObstacle method ends 
	
	
	public void startAcidTurret()
	{
		acidTurretC = true; //lets the program know that this obstacle is runnign 

		acidTurretT = new Timer(20, this); //new timer for the object moving 
		
		int xStart = 800; //starting point of the obstacles
		
		//random values for where the acid will shoot 
		//(made these values to make sure that it will always hit the player)
	    int yStart = Main.randomNumGenerator(100, 500); //starting point of the obstacles 
	    int xMax = Main.randomNumGenerator(0, 500); //max point 
	    int yMax = Main.randomNumGenerator(5, (yStart - 100)); //max point 
	    
	    acidTurretX = xStart; //set starting position 	    
		acidTurretY = yStart; //set starting position 
		
		//create the obstacle so it can be drawn
		acidTurret = new obstacles (acidTurretX, acidTurretY, 
		acidTurretWidth, acidTurretHeight, Color.GREEN);
		
		//Calculations for constants depending on the starting point and the max point  
		a = (yStart - yMax) / Math.pow((xStart - xMax), 2);
        b = -2 * a * xMax;
        c = yMax + a * Math.pow(xMax, 2);
		
        //every time the timer ticks it goes to this action listener 
		acidTurretT.addActionListener(new ActionListener()  
        {
            public void actionPerformed(ActionEvent e) 
            {
            	if(acidTurretX >= -acidTurretWidth) //if in frame then do this 
            	{
                    int x = acidTurretX; //to make the equation look cleaner 
                    
            		acidTurretX -= 10; // goes to the left -10
            		acidTurretY = (int)Math.round(a*x*x + b*x + c); // y = ax^2 + bx + c
            		
            		//set location of obstacle
            		acidTurret.setLocation(acidTurretX, acidTurretY); 
            		
            		checkCollision(); //check collision detection 
            		
            		repaint();//repaints the obstacle 
            	}//if ends 
            }  
        });
		acidTurretT.start(); //starts the timer 
	}//startAcidTurret method ends
	
	
//	@Override
//	public void actionPerformed(ActionEvent e) 
//	{
//		// TODO Auto-generated method stub
//		
//	}

	//testing collison detection 
	public void checkCollision()
	{
//		if(acidTurret.intersects(explodingBeaker))
//		{
//			System.out.println("collision between obstacles detected");
//			stopExplodingBeakerObstacle();
//			stopAcidTurretObstacle();
//			
//			
//		      try
//		      {
//		        // Delay for 4 seconds
//		        Thread.sleep(4000);   
//
//				
//				startAcidTurret(); //1st parameter is y starting position, 2nd is x position of tipping point, and 3rd is y position of tipping point  
//				startExplodingBeaker(5, 1); //first parameter is speed and second parameter is rate of expansion 
//
//
//
//		      }
//		      catch(InterruptedException ex)
//		      {
//		          ex.printStackTrace();
//		      }
//		}
	}
	
	

	
	

	
}
