//import libraries 
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Timer;

import javax.swing.JFrame;

public class Main extends JFrame 
{
	//size of the frame 
	static int frameWidth = 800;
	static int frameHeight = 500;
	public Timer game;
	public int seconds = 0;
	
	
	public static int getFrameWidth() //get method for frame width
	{
		return frameWidth; //returns the frame width variable
	}//getFrameWidth method ends
	
	public static int getFrameHeight() //get method for frame height 
	{
		return frameHeight; //returns the frame height variable 
	}//getFrameHeight method ends
	
	public static int randomNumGenerator(int min, int max)
	{
	    int num = (int)(Math.random()* (max - min + 1) + min); 
   	    return num; //returns the random number
	}   //method ends 
		
	public static void main(String[] args) 
	{
		JFrame frame = new JFrame(); //creats a new JFrame
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //sets up the x button
		frame.setResizable(false); //makes it so that the user cannot resize the frame 
		frame.setVisible(true); //sets the frame visible 
		frame.setSize(frameWidth, frameHeight); //sets frame size 
		frame.setLocationRelativeTo(null); //frame shows up in the middle of your screen 
		frame.setFocusable(true);
		frame.setFocusable(true);
		frame.requestFocus();
		ScienceLabObstacles sciencePanel = new ScienceLabObstacles();//creates a JPanel for the Science Lab Obstacles 
		frame.add(sciencePanel); //adds the JPanel to the frame 

		sciencePanel.startAcidTurret(); //1st parameter is y starting position, 2nd is x position of tipping point, and 3rd is y position of tipping point  
		//sciencePanel.startExplodingBeaker(5, 1); //first parameter is speed and second parameter is rate of expansion 
		//sciencePanel.startScientist();
		
	
		
	}
}

