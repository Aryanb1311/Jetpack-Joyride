import java.awt.BorderLayout;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class Main extends JFrame implements KeyListener {

	private JPanel contentPane;
	Canvas laserObstacle;
	Canvas laserDiscoBallObstacle;
	
	public int laserObstacleX = 140, laserObstacleY = 0, laserObstacleWidth = 186, laserObstacleHeight = 28;
	public int laserDiscoBallObstacleX = 173, laserDiscoBallObstacleY = 103, laserDiscoBallObstacleWidth = 46, laserDiscoBallObstacleHeight = 13;
	public int i = 0;
	public static Main frame = new Main();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Main() 
	{
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //closes frame when the x button is pressed 
		setBounds(100, 100, 724, 489); //sets frame size 
		setResizable(false); //makes it so that the user cannot change the size of the frame 
		setLocationRelativeTo(null); //make the frame show up in the middle of the screen
		setVisible(true); //sets the frame visible 
		setFocusable(true);
		
		contentPane = new JPanel(); //instantiates panel
		contentPane.setForeground(Color.WHITE); //sets colour of the panel
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5)); //border size of the panel
		setContentPane(contentPane); 
		contentPane.setLayout(null);
		
//		laserObstacle = new Canvas();
//		laserObstacle.setBackground(Color.ORANGE);
//		laserObstacle.setBounds(laserObstacleX, laserObstacleY, laserObstacleWidth, laserObstacleHeight);
//		contentPane.add(laserObstacle);
//		
//		Canvas acidObstacle = new Canvas();
//		acidObstacle.setBackground(Color.GREEN);
//		acidObstacle.setBounds(504, 106, 63, 20);
//		contentPane.add(acidObstacle);
//		
//		Canvas bulletObstacle = new Canvas();
//		bulletObstacle.setBackground(Color.DARK_GRAY);
//		bulletObstacle.setBounds(281, 340, 30, 13);
//		contentPane.add(bulletObstacle);
//		
//		Canvas droneObstacle = new Canvas();
//		droneObstacle.setBackground(Color.GRAY);
//		droneObstacle.setBounds(408, 340, 53, 34);
//		contentPane.add(droneObstacle);
//		
//		Canvas corruptedWiresObstacle = new Canvas();
//		corruptedWiresObstacle.setBackground(Color.BLUE);
//		corruptedWiresObstacle.setBounds(585, 329, 8, 54);
//		contentPane.add(corruptedWiresObstacle);
//		
//		Canvas discoBallObstacle = new Canvas();
//		discoBallObstacle.setBackground(Color.LIGHT_GRAY);
//		discoBallObstacle.setBounds(304, 26, 63, 63);
//		contentPane.add(discoBallObstacle);
//		
//		laserDiscoBallObstacle = new Canvas();
//		laserDiscoBallObstacle.setBackground(Color.RED);
//		laserDiscoBallObstacle.setBounds(laserDiscoBallObstacleX, laserDiscoBallObstacleY, laserDiscoBallObstacleWidth, laserDiscoBallObstacleHeight);
//		contentPane.add(laserDiscoBallObstacle);
//		
//		Canvas explodingBeakers = new Canvas();
//		explodingBeakers.setBackground(new Color(0, 100, 0));
//		explodingBeakers.setBounds(86, 334, 63, 40);
//		contentPane.add(explodingBeakers);
		this.addKeyListener(this);

	}
	public void paint(Graphics g)
	{
		g.fillRect(laserDiscoBallObstacleX, laserDiscoBallObstacleY, laserDiscoBallObstacleWidth, laserDiscoBallObstacleHeight);
		g.setColor(Color.BLUE);
	}

	
	public void keyPressed(KeyEvent e)
	{
		if(e.getKeyCode() == KeyEvent.VK_SPACE)
		{
			laserObstacleY++;
			laserObstacle.setLocation(140, laserObstacleY);
		}
		System.out.println(laserDiscoBallObstacle.getLocation());
		if(laserDiscoBallObstacle.getLocation() == laserObstacle.getLocation())
		{
			System.out.println("hola");
		}
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

}
