import java.awt.EventQueue;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Canvas;

public class Obstacles extends JPanel implements KeyListener 
{
	public int i = 0;
	Canvas laserObstacle;
	/**
	 * Create the panel.
	 */
	public Obstacles() 
	{		
		setLayout(null);
		
		laserObstacle = new Canvas();
		laserObstacle.setBackground(Color.ORANGE);
		laserObstacle.setBounds(140, 0, 186, 28);
		add(laserObstacle);
		
		Canvas acidObstacle = new Canvas();
		acidObstacle.setBackground(Color.GREEN);
		acidObstacle.setBounds(504, 106, 63, 20);
		add(acidObstacle);
		
		Canvas bulletObstacle = new Canvas();
		bulletObstacle.setBackground(Color.DARK_GRAY);
		bulletObstacle.setBounds(281, 340, 30, 13);
		add(bulletObstacle);
		
		Canvas droneObstacle = new Canvas();
		droneObstacle.setBackground(Color.GRAY);
		droneObstacle.setBounds(408, 340, 53, 34);
		add(droneObstacle);
		
		Canvas corruptedWiresObstacle = new Canvas();
		corruptedWiresObstacle.setBackground(Color.BLUE);
		corruptedWiresObstacle.setBounds(585, 329, 8, 54);
		add(corruptedWiresObstacle);
		
		Canvas discoBallObstacle = new Canvas();
		discoBallObstacle.setBackground(Color.LIGHT_GRAY);
		discoBallObstacle.setBounds(304, 26, 63, 63);
		add(discoBallObstacle);
		
		Canvas laserDiscoBallObstacle = new Canvas();
		laserDiscoBallObstacle.setBackground(Color.RED);
		laserDiscoBallObstacle.setBounds(173, 103, 46, 13);
		add(laserDiscoBallObstacle);
		
		Canvas explodingBeakers = new Canvas();
		explodingBeakers.setBackground(new Color(0, 100, 0));
		explodingBeakers.setBounds(86, 334, 63, 40);
		add(explodingBeakers);
		
		this.addKeyListener(this);
	}
	
	public void keyPressed(KeyEvent e)
	{
		if(e.getKeyCode() == KeyEvent.VK_SPACE )
		{
			i++;
			laserObstacle.setBounds(140, i, 186, 28);

		}
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

}
