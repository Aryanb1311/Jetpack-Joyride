
public class Boss {

}
