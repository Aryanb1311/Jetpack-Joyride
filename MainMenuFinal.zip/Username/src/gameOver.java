import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class gameOver extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					gameOver frame = new gameOver();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public gameOver() {
		setTitle("Game Over"); // Name of JFrame
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblGameOver = new JLabel("Game Over"); // label for gameover
		lblGameOver.setHorizontalAlignment(SwingConstants.CENTER);
		lblGameOver.setFont(new Font("Copperplate Gothic Bold", Font.BOLD, 26));
		lblGameOver.setBounds(120, 101, 177, 42);
		contentPane.add(lblGameOver);
		lblGameOver.setVisible(true);
		
		JLabel lblLivesEnd = new JLabel("You Have Run Out Of Lives"); // label for user to inform them they have run out of lives
		lblLivesEnd.setForeground(Color.RED);
		lblLivesEnd.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblLivesEnd.setBounds(130, 153, 171, 13);
		contentPane.add(lblLivesEnd);
		lblLivesEnd.setVisible(true);
		
		JButton btnPlayAgain = new JButton("Play Again"); // play again btn
		btnPlayAgain.setBounds(57, 213, 105, 40);
		contentPane.add(btnPlayAgain);
		btnPlayAgain.setVisible(true);
		
		JButton btnQuitGame = new JButton("Quit Game"); // quit game btn
		btnQuitGame.setBounds(296, 213, 96, 40);
		contentPane.add(btnQuitGame);
		btnQuitGame.setVisible(true);
		
		// Instructions button listener
		btnQuitGame.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});	
	}
}
