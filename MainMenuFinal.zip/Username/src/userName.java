/* Description: This program is for the main menu of the game as well as the game over screen. It includes the instructions for the game as 
 * well as a button to close the instructions, it also includes a textfield for the user to enter their username */


import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.JComboBox;
import java.awt.Color;
import javax.swing.SwingConstants;

public class userName extends JFrame {

	private JPanel contentPane;
	private JTextField nameTextField;
	
	Name userName = new Name();
	
	//Arrays
	Name userNames[] = new Name[100];
	
	//Variables
	public int user1Counter = 0;
	String name = ""; // name
	String nameSelected = " ";
	
	boolean editing = false;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					userName frame = new userName();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public userName() {
		setTitle("Jetpack Joyride Main Menu"); // Name of JFrame
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 700, 550);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblName = new JLabel("username"); // username label
		lblName.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblName.setBounds(10, 27, 73, 13);
		contentPane.add(lblName);
		
		nameTextField = new JTextField(); // username text field
		nameTextField.setBounds(93, 25, 96, 19);
		contentPane.add(nameTextField);
		nameTextField.setColumns(10);
		nameTextField.setEnabled(false);
		
		JButton btnAdd = new JButton("Add"); // Add Bttn
		btnAdd.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnAdd.setBounds(187, 107, 73, 23);
		contentPane.add(btnAdd);
		
		JButton btnSave = new JButton("Save"); // Save Button
		btnSave.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnSave.setBounds(10, 107, 84, 23);
		contentPane.add(btnSave);
		btnSave.setEnabled(false);
		
		JButton btnDelete = new JButton("Delete"); // Delete bttn
		btnDelete.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnDelete.setBounds(104, 107, 73, 23);
		contentPane.add(btnDelete);
		btnDelete.setEnabled(false);
		
		JComboBox viewCB = new JComboBox(); // combobox to view usernames 
		viewCB.setModel(new DefaultComboBoxModel(new String[] {"Select"}));
		viewCB.setBounds(303, 44, 123, 21);
		contentPane.add(viewCB);
		viewCB.setVisible(false);
		
		JLabel lblUser = new JLabel("User"); // label for user
		lblUser.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblUser.setBounds(335, 27, 45, 13);
		contentPane.add(lblUser);
		lblUser.setVisible(false);
		
		JLabel lblInstructions = new JLabel("Instructions"); // label for instructions
		lblInstructions.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblInstructions.setBounds(10, 173, 89, 13);
		contentPane.add(lblInstructions);
		
		JButton btnInstructions = new JButton("View Instructions"); // view instructions btn
		btnInstructions.setBounds(10, 197, 133, 31);
		contentPane.add(btnInstructions);
		
		JLabel lblInstructionsMove = new JLabel("-Press spacebar to go up and let go of spacebar to go down"); // label for instructions on how to move
		lblInstructionsMove.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblInstructionsMove.setBounds(20, 240, 360, 13);
		contentPane.add(lblInstructionsMove);
		lblInstructionsMove.setVisible(false);
		
		JLabel lblInstructionScore = new JLabel("-Your score is based on how long you are alive for and the bosses you defeat"); // label for instructions for score
		lblInstructionScore.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblInstructionScore.setBounds(10, 263, 449, 31);
		contentPane.add(lblInstructionScore);
		lblInstructionScore.setVisible(false);
		
		JButton btnPlay = new JButton("Play"); // Play btn
		btnPlay.setBounds(394, 121, 73, 43);
		contentPane.add(btnPlay);
		btnPlay.setVisible(false);
		
		// label for instructions on scenery and bosses
		JLabel lblInstructionSceneryBoss = new JLabel("-Each scenery except for default has a boss that you have to defeat and you will be granted 1 life for defeating the boss");
		lblInstructionSceneryBoss.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblInstructionSceneryBoss.setBounds(10, 304, 600, 13);
		contentPane.add(lblInstructionSceneryBoss);
		lblInstructionSceneryBoss.setVisible(false);
		
		// label for instructions on obstacle
		JLabel lblInstructionObstacle = new JLabel("-If you hit a obstacle you will lose 1 life and if you run out of lives you lose");
		lblInstructionObstacle.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblInstructionObstacle.setBounds(10, 340, 425, 13);
		contentPane.add(lblInstructionObstacle);
		lblInstructionObstacle.setVisible(false);
		
		JButton btnCloseInstructions = new JButton("Close Instructions"); // close instructions btn
		btnCloseInstructions.setBounds(394, 197, 141, 31);
		contentPane.add(btnCloseInstructions);
		btnCloseInstructions.setVisible(false);
		
		JButton btnDeleteUserName = new JButton("Delete Username");
		btnDeleteUserName.setBounds(450, 42, 136, 23);
		contentPane.add(btnDeleteUserName);
		btnDeleteUserName.setVisible(false);
		
		JButton btnCancel = new JButton("Cancel");
		btnCancel.setBounds(490, 75, 73, 21);
		contentPane.add(btnCancel);
		btnCancel.setVisible(false);
		
		// Add button listener
				btnAdd.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						btnSave.setEnabled(true); 
						nameTextField.setEnabled(true);
						nameTextField.setVisible(true);
						lblName.setVisible(true);
						btnCancel.setVisible(true);
						
						btnDelete.setEnabled(false);
					}
				});
				
		// Save Button Listener 
				btnSave.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {

						name = nameTextField.getText(); // gets name
						nameTextField.setVisible(false);
						lblName.setVisible(false);
						btnCancel.setVisible(false);
						
						btnDelete.setEnabled(true);
						
						viewCB.addItem(name);  // Adds fighter name to view 
						
						nameTextField.setText(null);
						
						editing = false; // reset editing
						
						userNames[user1Counter] = new Name(name);
						user1Counter++;
					}
				});
				
				// Cancel Button Listener 
				btnCancel.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {

						nameTextField.setVisible(false);
						lblName.setVisible(false);
						lblUser.setVisible(false);
						btnDeleteUserName.setVisible(false);
						btnCancel.setVisible(false);
						viewCB.setVisible(false);
						
						btnDelete.setEnabled(true);	
						btnAdd.setEnabled(true);
						btnSave.setEnabled(true);
						btnInstructions.setEnabled(true);
					}
				});
				
				// Instructions button listener
				btnInstructions.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						
						btnSave.setEnabled(false); // sets bttns edit, view, and delete to not enabled
						btnAdd.setEnabled(false);
						btnPlay.setEnabled(false);
						btnDelete.setEnabled(false);
						btnDeleteUserName.setEnabled(false);
						nameTextField.setEnabled(false);
						viewCB.setEnabled(false);
						
						lblInstructionsMove.setVisible(true);
						lblInstructionScore.setVisible(true);
						lblInstructionSceneryBoss.setVisible(true);
						lblInstructionObstacle.setVisible(true);
						btnCloseInstructions.setVisible(true);
					}
				});	
				
				// close instructions btn listener
				btnCloseInstructions.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						
						btnSave.setEnabled(false); // sets bttns edit, view, and delete to not enabled
						btnAdd.setEnabled(true);
						btnPlay.setEnabled(true);
						btnDelete.setEnabled(false);
						nameTextField.setEnabled(false);
						viewCB.setEnabled(true);
						
						lblInstructionsMove.setVisible(false);
						lblInstructionScore.setVisible(false);
						lblInstructionSceneryBoss.setVisible(false);
						lblInstructionObstacle.setVisible(false);
						nameTextField.setVisible(true);
						lblName.setVisible(true);
					}
				});	
				
				// Play Again Button Listener 
				btnDelete.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {

						// sets visible
						lblUser.setVisible(true);
						viewCB.setVisible(true);
						btnDeleteUserName.setVisible(true);
						btnCancel.setVisible(true);
						
						btnSave.setEnabled(false); // sets bttns edit, view, and delete to not enabled
						btnAdd.setEnabled(false);
						btnInstructions.setEnabled(false);
					}
				});
				
				// Delete Fighter button listener
				btnDeleteUserName.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						
						nameSelected = (String) viewCB.getSelectedItem();

						for (int i = 0; i < user1Counter; i++) // Saiyan Fighter search
						{
							//System.out.println(userNames[i]userNames.getName())); // troubleshoot print line

							if (nameSelected.equals(userNames[i].getName())) // Runs If name of fighter saiyan matched
							{
								viewCB.removeItem(userNames[i].getName()); // remove saiyan name from view combobox
								System.out.println("deleted!");
								for (int n = i; n < user1Counter - 1; n++) // subtract saiyan counter by 1, remove item from array and shift items
								{
									userNames[n] = userNames[n + 1];
								}
								user1Counter--; // reduce number of saiyan1 fighters by 1
							} // name match
						} // saiyan1
						// reset
						
						nameTextField.setText(null);

						btnDeleteUserName.setVisible(false); // sets fighter, view, confirm and cancel to visible
						btnCancel.setVisible(false);
						viewCB.setVisible(false);
						lblUser.setVisible(false);
						
						btnDelete.setEnabled(false);
						btnSave.setEnabled(false);
						btnAdd.setEnabled(true);
						btnInstructions.setEnabled(true);
					}
				}); // delete fighter button
	}
}
