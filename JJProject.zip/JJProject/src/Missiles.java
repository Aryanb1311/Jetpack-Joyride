import java.awt.Graphics;
import java.awt.Image;

public class Missiles {

	obstacle missile;
	Graphics graphics;
	Image missileImg;
	
	private static int FW = 400;
	private static int FH = 400;
	int x = 300;
	int y = 130;
	int w = 100; // the time the pc will take to move
	int v = 0;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
